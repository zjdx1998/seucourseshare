#include<iostream>
#include<string>
using namespace std;

class AtomList;

class Atom {

	friend class AtomList;
public:
	Atom(bool tag, string d="\0") {
		if (tag) {
			this->data = d;
			this->next = 0;
		}
		else {
			this->down = 0;
			this->next = 0;
		}
	}

	bool tag;
	Atom* down;
	string data;
	Atom* next;
};

class AtomList {

private:
	Atom* first;

public:
	AtomList() {
		first = new Atom(false);
	}
	void input();
	void deal(Atom*);
	Atom *getFirst() {
		return first;
	}

	string all;
};

