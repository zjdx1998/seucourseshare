#include"P222n3.h"
#include<algorithm>

istream& operator>>(istream& is, Martix& martix) {
	Triple s;
	is >> s.row >> s.col >> s.value;
	int p = max(s.row, s.col);
	martix.headnode = new Node(false, &s);
	if (!p) {
		martix.headnode->right = martix.headnode;
		return is;
	}

	Node** head = new Node*[p];
	for (int i = 0; i < p; i++) {
		head[i] = new Node(true, 0);
		head[i]->next = head[i];
	}
	int currentRow = 0;
	Node *last = head[0];
	for (int i = 0; i < s.value; i++) {
		Triple t;
		is >> t.row >> t.col >> t.value;
		if (t.row > currentRow) {
			last->right = head[currentRow];
			currentRow = t.row;
			last = head[currentRow];
		}
		last = last->right = new Node(false, &t);
		head[t.col]->next = head[t.col]->next->down = last;
	}
	last->right = head[currentRow];
	for (int i = 0; i < s.col; i++)
		head[i]->next->down = head[i];
	for (int i = 0; i < p - 1; i++)
		head[i]->next = head[i + 1];
	head[p - 1]->next = martix.headnode;
	martix.headnode->right = head[0];
	delete[]head;
	return is;
}

ostream& operator<<(ostream& os, Martix& martix) {
	Node* currentRow = martix.headnode->right;
	os << martix.headnode->triple.row << "��" << martix.headnode->triple.col << "��" << martix.headnode->triple.value << "��������" << endl;
	while (currentRow->head) {
		Node* item = currentRow->right;
		Triple t;
		while (!item->head) {
			t = item->triple;
			os << t.row << " " << t.col << " " << t.value << endl;
			item = item->right;
		}
		currentRow = currentRow->next;
	}
	return os;
}

int main() {
	Martix martix;
	cin >> martix;
	cout << martix;
	system("pause");
	return 0;
}