#pragma once
#include<iostream>
using namespace std;

struct Triple
{
	int row, col, value;
};

class Martix;

class Node {
	friend class Martix;
	friend istream& operator<<(istream&, Martix&);
	friend ostream& operator<<(ostream&, Martix&);
public:
	Node* down;
	Node* right;
	bool head;
	union {
		Node* next;
		Triple triple;
	};
	Node(bool b, Triple* t) {
		head = b;
		if (b)
			right = down = this;
		else
		{
			next = down = right = 0;
			triple = *t;
		}
	}
};

class Martix {
	friend istream& operator>>(istream&, Martix&);
	friend ostream& operator<<(ostream&, Martix&);
private:
	Node *headnode;
};
