/*
* Ԥ����д��Equivalence()Ч�ʵ���ԭ����
* ʹ�ÿռ����ԭ����
*/



#include<iostream>
#include<fstream>
#include<stack>
using namespace std;

template<typename T>
class Chain {
	friend void Equivalence();
public:
	Chain() {

	}

	stack<T> s;
};

void Equivalence() {
	int i, j, n;
	cout << "������Ԫ�ظ���:" << endl;
	cin >> n;
	if (n <= 0) {
		cout << "��������С��0";
		return;
	}
	Chain<int> *first = new Chain<int>[n];
	bool *out = new bool[n];
	fill(out, out + n, false);
	cout << "��ÿ������һ�Եȼ�Ԫ��(��EOF����):" << endl;
	while (cin >> i >> j)
	{
		first[i].s.push(j);
		first[j].s.push(i);
	}

	stack<Chain<int>> temp;

	for (i = 0; i < n; i++)
		if (!out[i]) {
			cout << "A new class: " << i << " ";
			out[i] = true;
			temp.push(first[i]);
			while (1) {
				while (out[temp.top().s.top()])
				{
					temp.top().s.pop();
					if (temp.top().s.size() == 0)
					{
						temp.pop();
						break;
					}
				}
				if (temp.empty())
					break;
				if (out[temp.top().s.top()])
					continue;
				int data = temp.top().s.top();
				cout << data << " ";
				out[data] = true;
				temp.push(first[data]);
			}
		cout << endl;
		}
}

int main() {
	Equivalence();

	system("pause");
	return 0;
}

