#include"P240n6.h"

void AtomList::input()
{
	cin >> all;
	deal(first);
	first->next = first->down;
}

void AtomList::deal(Atom *x)
{
	if (all[0] == '(') {
		Atom* t = new Atom(false);
		x = x->down = t;
		all = all.substr(1);
		cout << "down" << endl;
		deal(x);
	}
	while (true)
	{
		int i = 0;
		string temp = "";
		while (all[i] == ',' || all[i] == ' ') { i++; }
		all = all.substr(i);
		if (!all.length())
			return;
		i = 0;
		while (all[i] != ','&&all[i] != ')'&&all[i] != '(') {
			if (all[i] == ' ')
				continue;
			temp.push_back(all[i]);
			i++;
		}
		if (temp != "") {
		cout << "atom:  " << temp << endl;
			Atom *t = new Atom(true, temp);
			if (x->down&&!x->tag)
				x = t;
			else {
				x = x->next = t;
				cout << "next" << endl;
			}
		}
		if (all[i] == ')') {
			cout << "up" << endl;
			all = all.substr(i + 1);
			return;
		}
		if (all[i] == '(') {
			all = all.substr(i);
			deal(x);
		}			
		all = all.substr(i + 1);
	}
}

int main() {
	AtomList list;
	list.input();
	system("pause");
	return 0;
}
