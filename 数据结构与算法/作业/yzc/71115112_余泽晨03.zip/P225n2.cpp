#include"P225n2.h"

void DblList::Insert(Node * p, Node * x)
{//insert node p to the right of node x
	p->left = x;
	p->right = x->right;
	x->right->left = p;
	x->right = p;
}

void DblList::Delete(Node * x)
{
	if (x == first)
		cout << "Deletion of header node not permitted";
	else {
		x->left->right = x->right;
		x->right->left = x->left;
		delete x;
	}
}

void DblList::Concatenate(DblList m)
{
	Node* temp = m.first;
	m.first->left->right = first->left->right;
	first->left->right = m.first->right;
	temp->left = first->left;
	first->left = temp;
	delete temp;
}

void DblList::print()
{
	Node* t = first->right;
	while (t != first) {
		cout << t->data << "  ";
		t = t->right;
	}
	cout << endl;
}

int main() {
	DblList d1, d2;
	Node *t1 = new Node(2);
	Node *t2 = new Node(10);
	Node *t3 = new Node(12);
	d1.print();
	d1.Insert(t1, d1.getFirst());
	d1.Insert(t2, t1);
	d1.Insert(t3, t1);
	d1.print();
	d1.Delete(t3);
	d1.print();

	Node* t4 = new Node(0);
	d2.Insert(t4,d2.getFirst());
	d1.Concatenate(d2);
	d1.print();

	system("pause");
	return 0;
}
