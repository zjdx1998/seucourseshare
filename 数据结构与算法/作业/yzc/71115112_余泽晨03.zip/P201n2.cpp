#include"P201n2.h"
int main() {
	LinkedQueue<int> queue;
	queue.Pop();
	for (int i = 0; i < 5; i++) {
		queue.Push(i);
	}
	queue.print();
	queue.Pop();
	queue.print();
	system("pause");
	return 0;
}