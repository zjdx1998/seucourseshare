#pragma once
#include<iostream>
using namespace std;

template<class T>
class LinkedQueue;
template<class T>
class ChainNode {
	friend class LinkedQueue<T>;
public:
	ChainNode(T d,ChainNode* n = 0) {
		link = n;
		data = d;
	}
private:
	ChainNode* link;
	T data;
};
template<class T>
class LinkedQueue {
public:
	LinkedQueue() {
		front = rear = 0;
	}

	bool isEmpty() {
		return front == 0;
	}

	void Push(const T& e) {
		if (isEmpty()) {
			front = rear = new ChainNode<T>(e, 0);
		}
		else {
			rear = rear->link = new ChainNode<T>(e, 0);
		}
	}

	void Pop() {
		if (isEmpty()) {
			cout << "Queue is empty.Cannot delete" << endl;
		}
		else {
			ChainNode<T> *delNode = front;
			front = front->link;
			delete delNode;
		}
	}

	void print() {
		if (isEmpty()) {
			cout << "empty" << endl;
		}
		else {
			ChainNode<T>* temp = front;
			do {
				cout << temp->data<<"  ";
				temp = temp->link;
			} while (temp);
			cout << endl;
		}
	}

private:
	ChainNode<T>* front;
	ChainNode<T>* rear;
};
