#pragma once
#include<iostream>
using namespace std;

class DblList;
class Node {
	friend class DblList;
	
public:
	Node(int data) {
		this->data = data;
		left = right = this;
	}
private:
	int data;
	Node *left, *right;
};

class DblList {
private:
	Node* first;
public:
	DblList() {
		first = new Node(0);
	}
	void Insert(Node *p, Node *x);
	void Delete(Node *x);
	void Concatenate(DblList m);
	void print();
	Node* getFirst() {
		return first;
	}
};
