#include<iostream>
#include<fstream>
using namespace std;

ifstream infile("D:/input.txt");
ofstream outfile("D:/output.txt", ios::out);

bool **e;//��¼����λ��
int **s;//��¼���״̬
bool **bestx;//��¼���Ž�
int m, n, best, rlp, cp = 0, cm = 0;
int sx[5] = { 0,1,-1,0,0 }, sy[5] = { 0,0,0,1,-1 };

void set(int i, int j) {
	cp++;
	e[i][j] = 1;//���þ���
	//�ı侯����Χ�ļ��״̬
	for (int k = 0; k < 5; k++) {
		s[i+sx[k]][j+sy[k]]++;
		if (s[i + sx[k]][j + sy[k]] == 1)
			cm++;
	}
}

void reset(int i, int j) {
	cp--;	
	e[i][j] = 0;//���þ���
	//�ı侯����Χ�ļ��״̬
	for (int k = 0; k < 5; k++) {
		s[i + sx[k]][j + sy[k]]--;
		if (s[i + sx[k]][j + sy[k]] == 0)
			cm--;
	}
}

void search(int i, int j) {
	while (s[i][j]&&i<=m) {
		j++;
		if (j > n) {
			i++;
			j = 1;
		}		
	}
	if (i > m) {
		if (cp < best) {
			best = cp;
			for (int i = 1; i <= m; i++)
				for (int j = 1; j <= n; j++)
					bestx[i][j] = e[i][j];
		}
		return;
	}
	if ((m*n + 4 - cm) / 5 + cp >= best)
		return;
	if (j < n&&s[i][j + 1] == 0) {
		set(i, j + 1);
		search(i, j);
		reset(i, j + 1);
	}
	if (i < m && (s[i + 1][j] == 0 || s[i + 2][j] == 0)) {
		set(i + 1, j);
		search(i, j);
		reset(i + 1, j);
	}
	if (s[i + 1][j] == 0 && s[i][j + 1] == 0) {		
		set(i, j);
		search(i, j);
		reset(i, j);
	}
}

void print() {
	outfile << best << endl;
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++)
			outfile << bestx[i][j] << ' ';
		outfile << endl;
	}
}

void output() {
	cout << best << endl;
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++)
			cout << bestx[i][j] << ' ';
		cout << endl;
	}
}

int main() {		
	infile >> m >> n;
	best = m*n;
	//����ռ估��ʼ��
	e = new bool*[m + 2];
	s = new int*[m + 2];
	bestx = new bool*[m + 2];
	for (int i = 0; i <= m + 1; i++) {
		e[i] = new bool[n + 2];
		s[i] = new int[n + 2];
		bestx[i] = new bool[n + 2];
	}
	for (int i = 0; i <= m + 1; i++)
		for (int j = 0; j <= n + 1; j++)
		{
			e[i][j] = 0;
			s[i][j] = 0;
		}
	search(1, 1);
	print();
	output();
	system("pause");
	return 0;
}