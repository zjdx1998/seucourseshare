#include "P359n1.h"

Graph::Graph(int v)
{
	if (v < 0)
		throw"Graph's vertices cannot<0";
	vertices = v;
	edges = 0;
	edgeslist = new int*[vertices];
	for (int i = 0; i < vertices; i++) {
		edgeslist[i] = new int[vertices];
		fill(edgeslist[i], edgeslist[i] + vertices, 0);
	}
}

void Graph::Init()
{
	addEdge(0,1,28);
	addEdge(0,5,10);
	addEdge(1,2,16);
	addEdge(1,6,14);
	addEdge(2,3,12);
	addEdge(3,4,22);
	addEdge(3,6,18);
	addEdge(4,5,25);
	addEdge(4,6,24);
}

void Graph::addEdge(int u, int v, int weight)
{
	edgeslist[u][v] = edgeslist[v][u] = weight;
	edges++;
	Edge edge;
	edge.u = u;
	edge.v = v;
	edge.weight = weight;
	minheap.Push(edge);
}

void Graph::Kruskal()
{
	set = new Sets(vertices);
	Graph T(vertices);
	Edge edge;
	while (T.edges < vertices - 1 && !minheap.IsEmpty()) {
		edge = minheap.Top();
		minheap.Pop();
		if ((set->CollapsingFind(edge.u) != set->CollapsingFind(edge.v)))
		{
			T.addEdge(edge.u, edge.v, edge.weight);
			set->WeightedUnion(edge.u, edge.v);
		}
	}

	if (T.edges != T.vertices - 1)
		cout << "no spanning tree" << endl;
	else {
		bool** visited = new bool*[T.vertices];
		for (int i = 0; i < T.vertices; i++) {
			visited[i] = new bool[T.vertices];
			fill(visited[i], visited[i] + T.vertices, true);
		}
		int count = 0;
		for (int i = 0; count<T.edges; i++) {
			for (int j = 0; j < T.vertices; j++)
				if (T.edgeslist[i][j] && visited[i][j]) {
					cout << i << " " << j << " " << T.edgeslist[i][j] << "  " << endl;
					visited[j][i] = false;
					visited[i][j] = false;
					count++;
					i = j; 
					j = 0;
				}
		}
	}
}

int main()
{
	Graph g(7);
	g.Init();
	g.Kruskal();
	system("pause");
	return 0;
}