#pragma once
#include<iostream>
using namespace std;
struct Edge
{
	//u,v �����������������
	int u;
	int v;

	int weight;//Ȩ��
};

class MinHeap {
public:
	MinHeap(int size = 10) {
		if (size < 1) {
			cout << "error" << endl;
			return;
		}
		capacity = size;
		heapSize = 0;
		heap = new Edge[capacity + 1];
	}

	bool IsEmpty() const {
		return heapSize == 0;
	}

	const Edge& Top() const {
		return heap[1];
	}

	void Push(const Edge& e) {
		if (heapSize == capacity) {
			Edge* Newheap = new Edge[2 * capacity + 1];
			copy(heap, heap + heapSize + 1, Newheap);
			delete heap;
			heap = Newheap;
			capacity *= 2;
		}
		int currentNode = ++heapSize;
		while (currentNode != 1 && heap[currentNode / 2].weight > e.weight) {
			heap[currentNode] = heap[currentNode / 2];
			currentNode /= 2;
		}
		heap[currentNode] = e;
	}

	void Pop() {
		if (IsEmpty()) {
			cout << "error:heap is empty" << endl;
			return;
		}
		heap[1].~Edge();
		Edge e = heap[heapSize--];
		int currentNode = 1;
		int child = 2;
		while (child <= heapSize) {
			if (child < heapSize&&heap[child].weight > heap[child + 1].weight)
				child++;
			if (e.weight <= heap[child].weight)
				break;
			heap[currentNode] = heap[child];
			currentNode = child;
			child *= 2;
		}
		heap[currentNode] = e;
	}

private:
	Edge* heap;
	int heapSize;
	int capacity;
};

class Sets
{
public:
	Sets(int s = 1)
	{
		if (s < 1)
			throw "Set's size cannot < 1";
		n = s;
		parent = new int[s];
		fill(parent, parent + n, -1);
	}
	void WeightedUnion(int i, int j)
	{
		if (parent[i] < 0 && parent[j] < 0) {
			int temp = parent[i] + parent[j];
			if (parent[i] > parent[j]) {
				parent[i] = j;
				parent[j] = temp;
			}
			else {
				parent[j] = i;
				parent[i] = temp;
			}
		}
		else
			parent[j] = i;
	}
	int CollapsingFind(int i)//find root of i
	{
		int r = i;
		for (; parent[r] >= 0; r = parent[r]);
		while (i != r) {
			int s = parent[i];
			parent[i] = r;
			i = s;
		}
		return r;
	}
private:
	int *parent;
	int n;
};

class Graph {
public:
	Graph(int v=0);
	void Init();
	void addEdge(int u,int v,int weight);
	void Kruskal();

private:
	int vertices;
	int edges;
	MinHeap minheap;
	Sets* set;
	int** edgeslist;
};