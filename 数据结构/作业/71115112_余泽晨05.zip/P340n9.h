#pragma once

class AdjList;
class Node {
	friend class AdjList;

public:
	Node(int u = 0,int v = 0) {
		next = 0;
		this->u = u;
		this->v = v;
	}
private:
	int u;
	int v;
	Node* next;
};

class AdjList {
public:
	AdjList();

	void print();
private:
	Node** header;
	int vertices;
	int edges;
};