#pragma once

#include <list>
#include<iostream>
using namespace std;

// �ڽӱ��ڵ�
class AdjListNode {

private:
	int v;

public:
	AdjListNode(int v) {
		this->v = v;
	}

	int getV() {
		return v;
	}

};

// ͼ
class Graph {

private:
	int V;    // �������
	list<AdjListNode> *adj;
	int* dfn;
	int* low;
	int* lastV;//��¼���ڶ���
	int num;

public:
	Graph(int V);
	void addEdge(int u, int v);
	void tarjin();
	void tarjin(const int u, const int v);
	void getBridge();
};