#pragma once
#include<iostream>
using namespace std;

class AdjList;
class Node {
	friend class AdjList;
public:
	Node(int d) {
		data = d;
		next = 0;
	}
private:
	int data;
	Node* next;
};

class AdjList {
public:
	AdjList(int v);
	void InsertEdge(int u,int v);
	void DFS(int x);
	void DFS();
	void Components();
	void Output();
private:
	Node** list;
	int vertices;
	int edges;
	string newComponents;
	bool* visit;
};