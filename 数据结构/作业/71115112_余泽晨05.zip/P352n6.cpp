#include "P352n6.h"
#include<string>
#include<sstream>

AdjList::AdjList(int v)
{
	if (v <= 0)
		throw "����������>0";
	vertices = v;
	list = new Node*[v];
	for (int i = 0; i < v; i++) {
		list[i] = new Node(i);
	}
	newComponents = "";
	edges = 0;
	visit = new bool[vertices];
}

void AdjList::InsertEdge(int u, int v)
{
	if (u > vertices - 1 || v > vertices - 1 || u < 0 || v < 0)
		throw "���㲻����";
	Node* temp = list[u];
	while (temp->next) {
		temp = temp->next;
	}
	temp->next = new Node(v);
	temp = list[v];
	while (temp->next) {
		temp = temp->next;
	}
	temp->next = new Node(u);
	edges++;
	cout << "Insert edge (" << u << "," << v << ")" << endl;
}

void AdjList::DFS(int x)
{
	visit[x] = true;
	Node* current = list[x]->next;
	stringstream stream;
	stream << list[x]->data;
	newComponents += stream.str()+" ";
	while (current)
	{
		int v = current->data;
		if (!visit[v]) {
			DFS(v);
		}
		current = current->next;
	}
}

void AdjList::DFS()
{
	DFS(0);
}

void AdjList::Components()
{
	visit = new bool[vertices];
	fill(visit, visit + vertices, false);
	for (int i = 0; i < vertices; i++) {
		if (!visit[i]) {
			DFS(i);
			Output();
		}
	}
	delete[] visit;
}

void AdjList::Output()
{
	if (newComponents != "")
	{
		cout << newComponents << endl;
		newComponents = "";
	}
}

int main() {
	AdjList adjList(8);
	adjList.InsertEdge(1, 3);
	adjList.InsertEdge(1, 4);
	adjList.InsertEdge(3, 7);
	adjList.InsertEdge(2, 5);
	adjList.InsertEdge(2, 6);
	adjList.Components();
	system("pause");
	return 0;
}
