#include"P393n10.h"
#include<algorithm>

Graph::Graph(int v) {
	this->V = v;
	adj = new list<AdjListNode>[V];
}

void Graph::addEdge(int u, int v)
{
	AdjListNode nodev(v),nodeu(u);

	adj[u].push_back(nodev);
	adj[v].push_back(nodeu);

}

void Graph::tarjin()
{
	num = 1;
	dfn = new int[V];
	low = new int[V];
	lastV = new int[V];
	fill(dfn, dfn + V, 0);
	fill(low, low + V, 0);
	fill(lastV, lastV + V, -1);
	tarjin(0, -1);
	getBridge();
	delete[] dfn;
	delete[] low;
}

void Graph::tarjin(const int u, const int v)
{
	lastV[u] = v;
	dfn[u] = low[u] = num++;
	for (list<AdjListNode>::iterator i = adj[u].begin(); i != adj[u].end(); ++i) {
		int w = i->getV();
		if (dfn[w] == 0) {
			tarjin(w, u);
			low[u] = min(low[u], low[w]);		
		}
		else if (w != v)
			low[u] = min(low[u], dfn[w]);

	}
}

void Graph::getBridge()
{
	for (int i = 0; i < V; i++)
	{
		int v = lastV[i];
		if (v >= 0 && low[i] > dfn[v])
			cout << "bridge:" << v << " -> " << i << endl;
	}
}

int main() {
	Graph g(10);
	g.addEdge(0, 1);
	g.addEdge(1, 2);
	g.addEdge(1, 3);
	g.addEdge(2, 4);
	g.addEdge(3, 4);
	g.addEdge(3, 5);
	g.addEdge(5, 6);
	g.addEdge(5, 7);
	g.addEdge(6, 7);
	g.addEdge(7, 8);
	g.addEdge(7, 9);

	g.tarjin();
	system("pause");
	return 0;
}
