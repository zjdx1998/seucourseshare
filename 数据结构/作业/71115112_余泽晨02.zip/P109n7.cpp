#include<iostream>
#include<string>
using namespace std;
int* FailureFunction(string s, int *f)
{
	int length = s.length();
	f[0] = -1;
	for (int j = 1; j < length; j++)
	{
		int i = f[j - 1];
		while ((s[j] != s[i + 1]) && (i >= 0))
		{
			i = f[i];
		}
		if (s[j] == s[i + 1])
			f[j] = i + 1;
		else
			f[j] = -1;
	}
	return f;
}
int main()
{
	string pattern[4] = {"","aaaab","ababaa","abaabaabb"};
	int count = 0;
	while (count++ < 3)
	{
		//cin >> pattern;
		int *f = new int[pattern[count].length()];
		f = FailureFunction(pattern[count], f);
		cout << "-----------" << endl << "pattern" << count << endl;
		for (int i = 0; i < pattern[count].length(); i++)
			cout << "f[" << i << "]=" << f[i] << endl;
		cout << "-----------" << endl << endl;
	}
	system("pause");
	return 0;
}