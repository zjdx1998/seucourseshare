
//���ӳ�Ա����int���ͱ���sign,�ڹ��캯���н�sign��ʼ��Ϊ0

template<class T>
void Queue<T>::Push(const T & items)
{
	queue[rear] = items;
	rear = (rear + 1) % capacity;
	sign++;
	if (rear == front)
	{
		T* newQueue = new T[2 * capacity];
		int start = (front + 1) % capacity;
		if (start < 2)
			copy(queue + start, queue + capacity, newQueue);
		else
		{
			copy(queue + start, queue + capacity, newQueue);
			copy(queue, queue + rear, newQueue + capacity - start);
		}
		front = 0;
		rear = capacity - 1;
		capacity *= 2;
		delete[]queue;
		queue = newQueue;
		delete[]newQueue;
	}
}

template<class T>
void Queue<T>::Pop()
{
	if (IsEmpty() && !sign) throw"Queue is empty.Cannot delete";
	queue[front].~T();
	front = (front + 1) % capacity;
	sign--;
}