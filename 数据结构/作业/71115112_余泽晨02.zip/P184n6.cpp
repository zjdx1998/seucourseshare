void Chain::ToRight(ChainNode* l,ChainNode* r,int n)
{
	int i = 0;
	while (r->link&&i++ < n)
	{
		l = r;
		r = r->link;
	}
	if (!r->link)
	{
		l = r;
		r = 0;
	}
}
void Chain::ToLeft(ChainNode* l, ChainNode* r, int n)
{
	int i = 0;
	while (l->link&&i++ < n)
	{
		r = l;
		l = l->link;
	}
	if (!l->link)
	{
		r = l;
		l = 0;
	}
}