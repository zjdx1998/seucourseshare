#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;
int imove[8] = { -1,0,1,1,1,0,-1,-1 };
int jmove[8] = { 1,1,1,0,-1,-1,-1,0 };
void ValidWalk(int **room, int &ibug, int &jbug,int n,int m)
{
	int k=0;
	if (0 == ibug) 
	{
		if (0 == jbug)
			k = rand() % 3 + 1;
		else if (n - 1 == jbug)
			k = rand() % 3 + 3;
		else
			k = rand() % 5 + 1;			
	}
	else if (m - 1 == ibug)
	{
		if (n - 1 == jbug)
			k = rand() % 3 + 5;
		else if (0 == jbug)
		{
			k = rand() % 3;
			if (2 == k)
				k = 7;
		}
		else
		{
			k = rand() % 5 + 3;
			if (k < 5)
				k -= 3;
		}
	}
	else
	{
		if (n - 1 == jbug)
			k = rand() % 5 + 3;
		else if (0 == jbug)
		{
			k = rand() % 5;
			if (4 == k)
				k = 7;
		}
		else
			k = rand() % 8;
	}
	ibug += imove[k];
	jbug += jmove[k];
	room[jbug][ibug]++;
}
bool Examine(int **count, int n, int m)
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			if (0 == count[i][j])
				return false;
	return true;
}
int main()
{
	srand(time(NULL));	
	while (1)
	{
		int n = 10, m = 10, ibug = 0, jbug = 0;		
		while (cin>>n>>m)
		{
			if (n <= 2 || n >= 40 || m < 2 || m > 20)
				cout << "Invalid values,2<n<=40 and 2<=m<=20" << endl;
			else
				break;
		}
		while (cin >> ibug >> jbug)
		{
			if (ibug < 0 || ibug >= n || jbug < 0 || jbug >= m)
				cout << "Invalid values,0<=ibug<n,0<=jbug<m" << endl;
			else
				break;
		}
		int **room = new int*[n];
		for (int i = 0; i < n; i++)
		{
			room[i] = new int[m];
			fill(room[i], room[i] + m, 0);
		}
		int count = 0;
		room[jbug][ibug]++;
		for (; count++ < 50000; count++)
		{
			ValidWalk(room, ibug, jbug, n, m);
			if (Examine(room, n, m))
				break;
		}
		cout << count << endl;
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < m; j++)
				cout << room[i][j]<<" ";
			cout << endl;
		}
		cout << endl;
		//for (int i = 0; i < n; n++)
			//delete[] room[i];
		delete[] room;
	}
	system("pause");
	return 0;
}