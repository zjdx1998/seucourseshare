#include<iostream>
using namespace std;

int digit(int x, int i, int n) {
	if (1 == i)
		return x%n;
	if (0 == i)
		return x / n;
}

int RadixSort(int* set, int* link, int n) {
	int *e = new int[n], *f = new int[n];
	int first = 1;
	for (int i = 1; i < n; i++)
		link[i] = i + 1;
	link[n] = 0;

	for (int i = 1; i >= 0; i--) {
		fill(f, f + n, 0);

		for (int current = first; current; current = link[current]) {
			int k = digit(set[current], i, n);
			if (f[k] == 0)
				f[k] = current;
			else
				link[e[k]] = current;
			e[k] = current;
		}

		int j;
		for (j = 0; !f[j]; j++);
		first = f[j];
		int last = e[j];

		for (int k = j + 1; k < n; k++)
			if (f[k]) {
				link[last] = f[k];
				last = e[k];
			}

		link[last] = 0;
	}

	/*
	cout << "f: ";
	for (int i = 0; i < n; i++)
		cout << f[i] << " ";

	cout << endl << "e: ";
	for (int i = 0; i < n; i++)
		cout << e[i] << " ";

	cout << endl << "link: ";
	for (int i = 1; i < n+1; i++)
		cout << link[i] << " ";
	*/

	cout << endl << set[first] << " ";
	int temp=link[first];
	while (temp != 0) {
		cout << set[temp]<<" ";
		temp = link[temp];
	}
	return first;
}

int main() {
	int n;
	cin >> n;
	int *set = new int[n+1],*link = new int[n+1];
	for (int i = 0; i < n; i++)
		cin >> set[i+1];

	set[RadixSort(set, link, n)];

	system("pause");
	return 0;
}