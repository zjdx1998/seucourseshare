#include"P267n10.h"

template<class T>
Node<T>* Tree<T>::CopyNode(Node<T>* parent)
{
	if (!parent)
		return 0;
	return new Node<T>(parent->data,parent->leftC,parent->rightC);
}

template<class T>
Tree<T>::~Tree()
{
	Delete(root);
}

template<class T>
void Tree<T>::InsertLeft(Node<T> *parent, T s)
{
	Node<T> *leftchild = new Node<T>(s);
	if (parent->leftC)
		leftchild->leftC = parent->leftC;
	parent->leftC = leftchild;
}

template<class T>
void Tree<T>::InsertRight(Node<T> *parent, T s)
{
	Node<T> *rightchild = new Node<T>(s);
	if (parent->rightC)
		rightchild->rightC = parent->rightC;
	parent->rightC = rightchild;
}

template<class T>
void Tree<T>::Delete(Node<T> * t)
{
	if (!t) {
		if (!t->leftC&&!t->rightC) {
			t->leftC = t->rightC = 0;
			t = 0;
			return;
		}
		if (t->leftC)
			Delete(t->leftC);
		if (t->rightC)
			Delete(t->rightC);
		delete t;
	}
}

template<class T>
bool Tree<T>::empty()
{
	return root == 0;
}

template<class T>
Tree<T> Tree<T>::subLeftTree(Node<T> *t)
{
	return Tree<T>(t->leftC);
}

template<class T>
Tree<T> Tree<T>::subRightTree(Node<T> *t)
{
	return Tree<T>(t->rightC);
}

template<class T>
void Tree<T>::print()
{
	PreorderIterator<T> pri(*this);
	T t = pri.Next();
	while (t!="") {
		cout << t << " ";
		t = pri.Next();
	}
	cout << endl;

	InorderIterator<T> ii(*this);
	t = ii.Next();
	while (t != "") {
		cout << t << " ";
		t = ii.Next();
	}
	cout << endl;

	
	PostorderIterator<string> poi(*this);
	t = poi.Next();
	while (t != "") {
		cout << t << " ";
		t = poi.Next();
	}
	cout << endl;

	LevelorderIterator<T> li(*this);
	t = li.Next();
	while (t != "") {
		cout << t << " ";
		t = li.Next();
	}
	cout << endl;
	
}

template<class T>
T PreorderIterator<T>::Next()
{
	while (true) {
		if (currentNode) {
			s.push(currentNode);
			T temp = currentNode->data;
			currentNode = currentNode->leftC;
			return temp;
		}
		if (s.empty())
			return "";
		currentNode = s.top();
		s.pop();
		currentNode = currentNode->rightC;
	}
}

template<class T>
T InorderIterator<T>::Next()
{
	while (currentNode) {
		s.push(currentNode);
		currentNode = currentNode->leftC;
	}
	if (s.empty())
		return "";
	currentNode = s.top();
	currentNode->tag = 0;
	s.pop();
	T temp = currentNode->data;
	currentNode = currentNode->rightC;
	return temp;
}

template<class T>
T PostorderIterator<T>::Next()
{	
	while (true) {
		while (currentNode&&!currentNode->tag) {	
			s.push(currentNode);
			currentNode->tag++;
			currentNode = currentNode->leftC;
		}
		if (s.empty())
			return "";
		currentNode = s.top();
		if (currentNode->tag == 2) {
			T temp = currentNode->data;
			s.pop();
			if (s.empty())
				currentNode = 0;
			else
				currentNode = s.top();
			return temp;
		}
		currentNode->tag++;
		currentNode = currentNode->rightC;
	}
}

template<class T>
T LevelorderIterator<T>::Next()
{	
	if (!currentNode)
		return "";
	T temp = currentNode->data;
	if (currentNode->leftC)
		q.push(currentNode->leftC);
	if (currentNode->rightC)
		q.push(currentNode->rightC);
	if (!q.empty()) {
		currentNode = q.front();
		q.pop();
	}
	else
		currentNode = 0;
	return temp;
}

int main() {
	Node<string>* r = new Node<string>("A");
	Tree<string> tree(r);

	tree.InsertLeft(r, "B");
	tree.InsertLeft(r->leftC, "C");
	tree.InsertRight(r->leftC, "D");
	tree.InsertRight(r, "E");
	tree.InsertLeft(r->rightC, "F");
	tree.InsertRight(r->rightC, "G");
	tree.InsertRight(r->leftC, "H");
	
	cout << "tree1:" << endl;
	tree.print();

	cout << "------------------------" << endl << "tree2:" << endl;
	Tree<string> tree2(tree.GetRoot());
	tree2.print();

	cout << "------------------------" << endl << "subLeftTree:" << endl;
	Tree<string> subLtree(tree.GetRoot()->leftC);
	subLtree.print();

	cout << "------------------------" << endl << "subRightTree:" << endl;
	Tree<string> subRtree(tree.GetRoot()->rightC);
	subRtree.print();
	system("pause");
	return 0;
}