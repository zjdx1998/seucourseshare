#include "P323n5.h"
#include<string>

//�������ڶ�������Ӧ�����ǰ�����������,�����������
void Tree::CreateTree(Node* r, string preOrder, string inOrder)
{
	if (preOrder.length() == 0)
		return;
	char rootdata = preOrder[0];
	int index = inOrder.find(rootdata);
	r->data = rootdata;
	string leftPre = preOrder.substr(1, index);
	if (leftPre.length() == 0)
		return;
	string leftIn = inOrder.substr(0, index);
	r->leftChild = new Node();
	CreateTree(r->leftChild, leftPre, leftIn);
	string rightPre = preOrder.substr(index + 1);
	if (rightPre.length() == 0)
		return;
	string rightIn = inOrder.substr(index + 1);
	r->rightChild = new Node();
	CreateTree(r->rightChild, rightPre, rightIn);
}

void Tree::CreateTree(string preOrder, string inOrder)
{
	cout << "PreOrder:" << preOrder << "  &&  InOrder:" << inOrder << endl;
	CreateTree(root, preOrder, inOrder);
}

void Tree::PreOrder(Node * r)
{
	if (r) {
		cout << r->data << " ";
		PreOrder(r->leftChild);
		PreOrder(r->rightChild);
	}
}

void Tree::PreOrder()
{
	cout << "PreOrder:";
	PreOrder(root);
	cout << endl;
}

void Tree::InOrder(Node * r)
{
	if (r) {
		InOrder(r->leftChild);
		cout << r->data << " ";
		InOrder(r->rightChild);
	}
}

void Tree::InOrder()
{
	cout << "InOrder:";
	InOrder(root);
	cout << endl;
}

int main() {
	Tree tree;
	tree.CreateTree("ABCHDEFG", "HCBDAFEG");	
	tree.PreOrder();	
	tree.InOrder();

	cout << endl;
	tree.CreateTree("ABCDEFG", "CBDAFEG");
	tree.PreOrder();
	tree.InOrder();

	cout << endl;
	tree.CreateTree("ABCDEFG", "CBEDAFG");
	cout << "�����ڶ�����ͬʱ��Ӧ�����ǰ��������,�����������" << endl;
	tree.PreOrder();
	tree.InOrder();

	system("pause");
	return 0;
}
