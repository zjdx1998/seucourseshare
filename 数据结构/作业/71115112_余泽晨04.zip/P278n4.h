#pragma once
#include<iostream>
using namespace std;
template<class T>
class Tree;
template<class T>
class Node {
	friend class Tree<T>;
public:
	Node<T>* leftC;
	Node<T>* rightC;
	T data;
	bool leftThread;
	bool rightThread;

	Node(T s) {
		leftC = 0;
		rightC = 0;
		data = s;
		leftThread = rightThread = true;
	}
	Node() {
		leftC = rightC = 0;
		leftThread = rightThread = true;
	}

};

template<class T>
class Tree {
public:
	Tree(T a) {
		root = new Node<T>();
		root->rightC = root;
		root->rightThread = false;
		InsertLeft(root, a);
		currentNode = root;
	};

	Node<T>* GetRoot() {
		return root;
	}


	void InsertRight(Node<T>*, T);
	void InsertLeft(Node<T>*, T);
	Node<T>* InorderSucc(Node<T>*);
	T Next();
	void Preorder();

private:
	Node<T>* root;
	Node<T>* currentNode;
};


