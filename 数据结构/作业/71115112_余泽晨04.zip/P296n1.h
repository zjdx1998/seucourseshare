#pragma once
#include<iostream>
using namespace std;

template<class K,class E>
class BST;

template< class K, class E >
class Node {
	friend class BST<K,E>;

public:
	Node(pair<K, E> d) {
		leftChild = rightChild = 0;
		data = d;
	}

	Node() {
		leftChild = rightChild = 0;
	};

private:
	pair<K, E> data;
	Node<K, E>* leftChild;
	Node<K, E>* rightChild;
};

template<class K, class E>
class BST {
public:
	BST() {
		root = 0;
	}

	BST(Node<K,E>* r) {
		root = r;
	}

	bool IsEmpty() {
		return root == 0;
	}

	pair<K, E> Get(const K& k) {
		return Get(k,root);
	}
	pair<K, E> Get(const K&, Node<K, E> *r);

	void Insert(const pair<K, E>&);

	void Delete(const K&);

private:
	Node<K, E> *root;
	Node<K, E> *lastNode;
};


