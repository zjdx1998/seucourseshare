//ǰ�������ʱ�临���ԺͿռ临���Զ���O(n)

#include"P278n4.h"
#include<string>

template<class T>
void Tree<T>::InsertRight(Node<T>* s, T d)
{
	Node<T>* r = new Node<T>(d);
	r->rightC = s->rightC;
	r->rightThread = s->rightThread;
	r->leftC = s;
	r->leftThread = true;
	s->rightC = r;
	s->rightThread = false;
	if (!r->rightThread) {
		Node<T>* temp = InorderSucc(r);
		temp->leftC = r;
	}
}

template<class T>
void Tree<T>::InsertLeft(Node<T>* s, T d)
{
	Node<T>* r = new Node<T>(d);
	r->leftC = s->leftC;
	r->leftThread = s->leftThread;
	r->rightC = s;
	r->rightThread = true;
	s->leftC = r;
	s->leftThread = false;
	if (!r->leftThread) {
		Node<T>* temp = InorderSucc(r);
		temp->rightC = r;
	}
}

template<class T>
Node<T>* Tree<T>::InorderSucc(Node<T>* r)
{
	Node<T>* curr = r;
	Node<T>* temp = curr->rightC;
	if (!curr->rightThread)
		while (!temp->leftThread)temp = temp->leftC;
	curr = temp;
	return curr;
}

template<class T>
T Tree<T>::Next()
{
	if (!currentNode->leftThread)
		currentNode = currentNode->leftC;
	else if (!currentNode->rightThread)
		currentNode = currentNode->rightC;
	else
		currentNode = currentNode->rightC->rightC;
	if (currentNode == root)
		return "";
	return currentNode->data;
}

template<class T>
void Tree<T>::Preorder()
{
	T s;
	s = Next();
	while (s!="") {
		cout << s << " ";
		s = Next();
	}
	cout << endl;
}

int main() {
	Tree<string> tree("A");
	Node<string>* r = tree.GetRoot();
	tree.InsertLeft(r->leftC, "B");
	tree.InsertRight(r->leftC, "C");
	tree.InsertLeft(r->leftC->leftC, "D");
	tree.InsertRight(r->leftC->leftC, "E");
	tree.InsertLeft(r->leftC->rightC, "F");
	tree.InsertRight(r->leftC->rightC, "G");
	tree.InsertLeft(r->leftC->leftC->leftC, "H");
	tree.InsertRight(r->leftC->leftC->leftC, "I");

	tree.Preorder();
	system("pause");
	return 0;
}
