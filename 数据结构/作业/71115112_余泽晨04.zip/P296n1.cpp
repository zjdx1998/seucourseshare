//ʱ�临�Ӷ��Ƕ����������߶�

#include"P296n1.h"

template<class K, class E>
pair<K, E> BST<K, E>::Get(const K &k, Node<K, E>* r)
{
	if (!r) {
		cout << "not found" << endl;
		return pair<K, E>(0, 0);
	}
	if (k != r->data.first)
		lastNode = r;
	if (k < r->data.first)
		return Get(k, r->leftChild);
	if (k > r->data.first)
		return Get(k, r->rightChild);
	return r->data;
}

template<class K, class E>
void BST<K, E>::Insert(const pair<K, E>& Pair)
{
	Node<K, E>* p = root, *pp = 0;
	while (p) {
		pp = p;
		if (Pair.first < p->data.first)
			p = p->leftChild;
		else if (Pair.first>p->data.first)
			p = p->rightChild;
		else {
			p->data.second = Pair.second;
			return;
		}	
	}

	p = new Node<K, E>(Pair);
	if (root)
		if (Pair.first < pp->data.first)
			pp->leftChild = p;
		else
			pp->rightChild = p;
	else
		root = p;
}

template<class K, class E>
void BST<K, E>::Delete(const K &k)
{
	pair<K, E> Pair = Get(k);
	if (Pair==pair<K,E>(0,0)) {
		cout << "error.This key doesn't exist." << endl;
		return;
	}
	Node<K, E>* temp;
	bool left;
	if (lastNode->leftChild&&lastNode->leftChild->data== Pair)
	{
		temp = lastNode->leftChild;
		left = true;
	}
	else {
		temp = lastNode->rightChild;
		left = false;
	}
	if (!temp->leftChild&&!temp->rightChild) {		
		if (left)
			lastNode->leftChild = 0;
		else
			lastNode->rightChild = 0;
	}
	else if (temp->leftChild&&!temp->rightChild) {
		if (left)
			lastNode->leftChild = temp->leftChild;
		else
			lastNode->rightChild = temp->leftChild;
	}
	else if (!temp->leftChild) {
		if (left)
			lastNode->leftChild = temp->rightChild;
		else
			lastNode->rightChild = temp->rightChild;
	}
	else {
		Node<K, E> *lm = temp->leftChild;
		while (lm->rightChild)
			lm = lm->rightChild;
		temp->data = lm->data;
		temp = lm;
	}
	delete temp;
}


int main() {
	BST<int,int> n;
	for (int i = 1; i < 8; i++) {
		n.Insert(pair<int, int>(i, 11 * i));
		cout << "insert:(" << i << "," << 11 * i << ")" << endl;
	}
	for (int i = 1; i < 8; i++) {
		cout << "key:" << i << endl << "value: " << n.Get(i).second << endl;
	}
	cout << "key : " << 8 << "  ";
	n.Get(8);

	n.Delete(4);
	cout << "delete:4" << endl;
	n.Delete(5);
	cout << "delete:5" << endl;

	for (int i = 1; i < 8; i++) {
		cout << "key:" << i << endl << "value: " << n.Get(i).second << endl;
	}

	system("pause");
	return 0;
}