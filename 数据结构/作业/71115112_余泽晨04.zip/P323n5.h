#pragma once
#include<iostream>
using namespace std;

class Tree;
class Node {
	friend class Tree;

public:
	Node(char data='0') {
		this->data = data;
		leftChild = rightChild = 0;
	}

private:
	Node* leftChild;
	Node* rightChild;
	char data;
};

class Tree {
public:
	Tree() {
		root = new Node();
	}

	void CreateTree(Node* r,string preOrder,string inOrder);
	void CreateTree(string preOrder, string inOrder);
	void PreOrder(Node * r);
	void PreOrder();
	void InOrder(Node* r);
	void InOrder();

private:
	Node* root;
};