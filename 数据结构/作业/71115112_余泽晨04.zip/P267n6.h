#pragma once
#include<iostream>
using namespace std;
#include<string>
template<class T>
class Tree;
template<class T>
class Node {
	friend class Tree<T>;
public:
	Node<T>* leftC;
	Node<T>* rightC;
	T data;

	Node(T s) {
		leftC = 0;
		rightC = 0;
		data = s;
	}

};

template<class T>
class Tree {
public:
	Tree(Node<T>* n=0) {
		root = n;
	}

	void InsertLeft(Node<T> *, T);
	void InsertRight(Node<T> *, T);
	void NonrecPreorder();
	void NonrecPreorder(Node<T> *);

private:
	Node<T>* root;
};