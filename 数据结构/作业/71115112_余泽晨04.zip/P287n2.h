#pragma once
#include<iostream>
using namespace std;

template<class T>
class MinPQ {
public:
	virtual ~MinPQ() {};

	virtual bool IsEmpty() const = 0;

	virtual const T& Top() const = 0;

	virtual void Push(const T&) = 0;

	virtual void Pop() = 0;
};

template<class T>
class MinHeap :public MinPQ<T> {
public:
	MinHeap(int size = 10) {
		if (size < 1) {
			cout << "error" << endl;
			return;
		}
		capacity = size;
		heapSize = 0;
		heap = new T[capacity + 1];
	}

	bool IsEmpty() const {
		return heapSize == 0;
	}

	const T& Top() const {
		return heap[1];
	}

	void Push(const T& e) {
		if (heapSize == capacity) {
			T* Newheap = new T[2 * capacity + 1];
			copy(heap, heap + heapSize + 1, Newheap);
			delete heap;
			heap = Newheap;
			capacity *= 2;
		}
		int currentNode = ++heapSize;
		while (currentNode != 1 && heap[currentNode / 2] > e) {
			heap[currentNode] = heap[currentNode / 2];
			currentNode /= 2;
		}
		heap[currentNode] = e;
	}

	void Pop() {
		if (IsEmpty()) {
			cout << "error:heap is empty" << endl;
			return;
		}
		heap[1].~T();
		T e = heap[heapSize--];
		int currentNode = 1;
		int child = 2;
		while (child<=heapSize) {
			if (child < heapSize&&heap[child] > heap[child + 1])
				child++;
			if (e <= heap[child])
				break;
			heap[currentNode] = heap[child];
			currentNode = child;
			child *= 2;
		}
		heap[currentNode] = e;
	}

//private:
	T* heap;
	int heapSize;
	int capacity;
};