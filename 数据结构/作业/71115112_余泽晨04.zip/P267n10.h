#pragma once
#include<iostream>
using namespace std;
#include<string>
#include<stack>
#include<queue>
template<class T>
class Tree;
template<class T>
class PreorderIterator;
template<class T>
class InorderIterator;
template<class T>
class PostorderIterator;
template<class T>
class LevelorderIterator;

template<class T>
class Node {
	friend class Tree<T>;
	friend class PreorderIterator<T>;
	friend class InorderIterator<T>;
	friend class PostorderIterator<T>;
	friend class LevelorderIterator<T>;

public:
	Node<T>* leftC;
	Node<T>* rightC;
	T data;
	int tag;

	Node(T s) {
		leftC = 0;
		rightC = 0;
		data = s;
		tag = 0;
	};
	Node(T s,Node<T>* l,Node<T>* r) {
		leftC = l;
		rightC = r;
		data = s;
		tag = 0;
	};
};

template<class T>
class Tree {
	friend class PreorderIterator<T>;
	friend class InorderIterator<T>;
	friend class PostorderIterator<T>;
	friend class LevelorderIterator<T>;
private:
	Node<T>* root;
public:
	Tree(Node<T>* r = 0) {
		root = r;
	};

	Tree(Tree<T>& t)
	{
		root = CopyNode(t->root);
	};

	Node<T>* GetRoot() {
		return root;
	}

	Node<T>* CopyNode(Node<T>*);

	~Tree();

	void Delete(Node<T> *);

	void InsertLeft(Node<T> *, T);
	void InsertRight(Node<T> *, T);

	bool empty();

	Tree<T> subLeftTree(Node<T>*);
	Tree<T> subRightTree(Node<T>*);

	void print();
};

template<class T>
class PreorderIterator
{
	friend class Tree<T>;
public:
	PreorderIterator(Tree<T>& t) {
		currentNode = t.root;
	};
	T Next();
private:
	stack<Node<T>*> s;
	Node<T>* currentNode;
};

template<class T>
class InorderIterator
{
	friend class Tree<T>;
public:
	InorderIterator(Tree<T>& t) {
		currentNode = t.root;
	};
	T Next();
private:
	stack<Node<T>*> s;
	Node<T>* currentNode;
};

template<class T>
class PostorderIterator
{
	friend class Tree<T>;
public:
	PostorderIterator(Tree<T>& t) {
		currentNode = t.root;
	};
	T Next();
private:
	stack<Node<T>*> s;
	Node<T>* currentNode;
};

template<class T>
class LevelorderIterator
{
	friend class Tree<T>;
public:
	LevelorderIterator(Tree<T>& t) {
		currentNode = t.root;
	};
	T Next();
private:
	queue<Node<T>*> q;
	Node<T>* currentNode;
};