#include"P287n2.h"

int main() {
	MinHeap<int> minheap;
	cout << "push:";
	for (int i = 6; i > 0; i--)
	{
		minheap.Push(i*10);
		cout << minheap.Top() << " ";
	}

	minheap.Push(25);
	minheap.Push(35);
	cout << 25 << " " << 35 << endl;

	for (int i = 1; i <= minheap.heapSize; i++)
		cout << minheap.heap[i] << " ";	

	cout << endl;

	while (!minheap.IsEmpty()) {
		cout << "Pop:" << minheap.Top() << endl;
		minheap.Pop();
		for (int i = 1; i <= minheap.heapSize; i++)
			cout << minheap.heap[i] << " ";
		cout << endl;
	}
	system("pause");
	return 0;
}