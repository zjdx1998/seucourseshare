#include"P267n6.h"
#include<stack>
template<class T>
void Tree<T>::InsertLeft(Node<T> *parent, T s)
{
	Node<T> *leftchild = new Node<T>(s);
	if (parent->leftC)
		leftchild->leftC = parent->leftC;
	parent->leftC = leftchild;
}

template<class T>
void Tree<T>::InsertRight(Node<T> *parent, T s)
{
	Node<T> *rightchild = new Node<T>(s);
	if (parent->rightC)
		rightchild->rightC = parent->rightC;
	parent->rightC = rightchild;
}

template<class T>
void Tree<T>::NonrecPreorder()
{
	NonrecPreorder(root);
}

template<class T>
void Tree<T>::NonrecPreorder(Node<T> *p)
{
	stack<Node<T>*> s;
	Node<T>* currentNode = p;
	while (true)
	{
		while (currentNode) {
			s.push(currentNode);
			cout << currentNode->data << " ";
			currentNode = currentNode->leftC;
		}
		if (s.empty())
			return;
		currentNode = s.top();
		s.pop();
		currentNode=currentNode->rightC;
	}
}

int main() {
	Node<string>* r = new Node<string>("A");
	Tree<string> tree(r);

	tree.InsertLeft(r, "B");
	tree.InsertLeft(r->leftC, "C");
	tree.InsertRight(r->leftC, "D");
	tree.InsertRight(r, "E");
	tree.InsertLeft(r->rightC, "F");
	tree.InsertRight(r->rightC, "G");
	tree.InsertLeft(r->leftC, "H");

	tree.NonrecPreorder();
	cout << endl;

	tree.NonrecPreorder(r->leftC);
	cout << endl;

	tree.NonrecPreorder(r->rightC);
	cout << endl;

	system("pause");
	return 0;
}