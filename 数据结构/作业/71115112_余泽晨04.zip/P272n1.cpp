//�������ĵĽڵ�Ϊn,�����Ҷ�ڵ��ʱ��ΪO(n)
#include<stack>
#include "P272n1.h"
template<class T>
void Tree<T>::InsertLeft(Node<T> *parent, T s)
{	
	Node<T> *leftchild = new Node<T>(s);
	if(parent->leftC)
		leftchild->leftC = parent->leftC;
	parent->leftC = leftchild;
}

template<class T>
void Tree<T>::InsertRight(Node<T> *parent, T s)
{
	Node<T> *rightchild = new Node<T>(s);
	if (parent->rightC)
		rightchild->rightC = parent->rightC;
	parent->rightC = rightchild;
}

template<class T>
int Tree<T>::Leaves()
{
	return Leaves(root);
}

template<class T>
int Tree<T>::Leaves(Node<T>* n)
{
	if (!n->leftC&&!n->rightC)
		return 1;
	else if (n->leftC&&!n->rightC)
		return Leaves(n->leftC);
	else if (!n->leftC&&n->rightC)
		return Leaves(n->rightC);
	else
		return Leaves(n->leftC) + Leaves(n->rightC);
}

int main() {
	Node<string>* r = new Node<string>("A");
	Tree<string> tree(r);

	tree.InsertLeft(r, "B");
	tree.InsertLeft(r->leftC, "C");
	tree.InsertRight(r->leftC, "D");
	tree.InsertRight(r, "E");
	tree.InsertLeft(r->rightC, "F");
	tree.InsertRight(r->rightC, "G");

	cout << tree.Leaves() << endl;

	tree.InsertRight(r->rightC, "H");
	cout << tree.Leaves() << endl;

	system("pause");
	return 0;
}