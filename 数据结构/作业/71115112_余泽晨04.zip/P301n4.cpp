#include "P301n4.h"

#include<stdarg.h>

void LoserTree::Construct(int r1, ...)
{
	int* ptr = &r1;
	int i = run;
	int temp = 0;
	while (temp < i) {
		lt[i + temp] = *ptr;
		temp++;
		ptr++;
	}
	i /= 2;
	ptr = 0;
	while (i > 0) {
		temp = 0;
		while (temp < i) {
			int index = i + temp;
			lt[index] = (lt[index * 2]<lt[index * 2 + 1] ? lt[index * 2] : lt[index * 2 + 1]);
			temp++;
		}
		i /= 2;
	}

	lt[0] = lt[1];
	i = 1;
	while (i < run) {
		temp = 0;
		while (temp < i) {
			int index = i + temp;
			lt[index] = (lt[index * 2]>lt[index * 2 + 1] ? lt[index * 2] : lt[index * 2 + 1]);
			temp++;
		}
		i *= 2;
	}
}

void LoserTree::print()
{
	for (int i = 0; i < run * 2; i++)
		cout << lt[i] << " ";
	cout << endl;
}

int LoserTree::top()
{
	return lt[0];
}

int main() {
	LoserTree loserTree(8);
	loserTree.Construct(10, 9, 20, 6, 8, 9, 90, 17);
	cout << "top:" << loserTree.top() << endl << "loserTree:";
	loserTree.print();
	system("pause");
	return 0;
}