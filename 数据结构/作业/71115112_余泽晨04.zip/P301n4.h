#pragma once
#include<iostream>
using namespace std;

class LoserTree {
public:
	LoserTree(int k = 0) {
		run = k;
		lt = new int[run * 2];
		fill(lt, lt + run * 2, 0);
	}
	void Construct(int r1, ...);

	void print();
	int top();

private:
	int* lt;//loserTree
	int run;
};