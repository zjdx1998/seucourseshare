#include<iostream>
#include<algorithm>
#include<Windows.h>
#include<ctime>
using namespace std;
int BinarySearch(int *a, const int x, const int n)
{
	int left = 0, right = n - 1;
	while (left <= right)
	{
		int middle = (left + right) / 2;
		if (x < a[middle])
			right = middle - 1;
		else if (x>a[middle])
			left = middle + 1;
		else
			return middle;
	}
	return -1;
}
int main()
{
	srand(time(0));
	const int times[10] = {10000000,5000000,3000000,2500000,2000000,1500000,1500000,1000000,1000000,1000000 };
	long start, end;
	int n[10];
	for (int i = 0; i < 10; i++)
		n[i] = 10 * (i + 1);
	int a[101],b[101];	
	cout << "  number  n  totalTime  runTime" << endl;
	float Ttime,averageTime;
	for (int i = 0; i < 10; i++)
	{
		Ttime = 0;
		for (int i = 0; i<101; i++)
		{
			b[i] = i;
		}
		for (int mi = 0, mj = 100; mi<n[i]; mi++, mj--)
		{
			int mk = rand() % mj;
			a[mi] = b[mk];
			if (mk != mj)
				b[mk] = b[mj];
		}
		sort(a, a + n[i]);
		a[n[i]] = -1;
		for (int k = 0; k <= n[i]; k++)
		{			
			start = GetTickCount();
			for (int c = 0; c < times[i];c++)
				BinarySearch(a, a[k], n[i]);
			end = GetTickCount();
			long totaltime = end - start;
			float runtime = (float)(totaltime) / (float)(times[i]);
			cout << a[k] << "  " << times[i] << "  " << totaltime << "  " << runtime<<endl;
			Ttime += runtime;
		}
		averageTime = Ttime*1.0 / (n[i] + 1);
		cout << "---------------------------\n";
		cout << "averageTime   " << averageTime << endl;
		cout << "---------------------------\n";
	}
	system("pause");
}