#include<iostream>
using namespace std;
int n, m;
int compare(int *a, int *b)
{
	int i = 0;
	while (i < m&&i < n)
	{
		if (a[i] < b[i])
			return -1;
		else if (a[i] > b[i])
			return 1;
		i++;
	}
	if (m<n)
		return -1;
	else if (m>n)
		return 1;
	else
		return 0;
}
int main()
{
	while (cin >> m >> n)
	{
		int *a = new int[m], *b = new int[n];
		for (int i = 0; i < m; i++)
		{
			cin >> a[i];
		}
		for (int i = 0; i < n; i++)
		{
			cin >> b[i];
		}
		cout << compare(a, b) << endl;
	}
	system("pause");
	return 0;
}