SparseMatrix SparseMatrix::FastTranspose()
{
	SparseMatrix b(cols, rows, terms);
	if (terms > 0)
	{
		int* rowStart = new int[cols + 1];
		fill(rowStart, rowStart + cols + 1, 0);
		for (int i = 0; i < terms; i++)
		{
			rowStart[SMArray[i].col + 1]++;
		}
		rowStart[0] = 0;
		for (int i = 1; i < cols; i++)
		{
			rowStart[i] += rowStart[i - 1];
		}
		for (int i = 0; i < terms; i++)
		{
			int j = rowStart[SMArray[i].col];
			b.SMArray[j].row = SMArray[i].col;
			b.SMArray[j].col = SMArray[i].row;
			b.SMArray[j].value = SMArray[i].value;
			rowStart[SMArray[i].col]++;
		}
		delete[]rowStart;
	}
	return b;
}