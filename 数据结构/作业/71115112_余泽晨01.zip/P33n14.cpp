#include<iostream>
using namespace std;
int total, n;
void powerset(char *set, char *temp, int count)
{
	char tempSet[100];
	strcpy(tempSet, temp);
	if (count >= n)
	{
		cout << "{" << tempSet << "}" << endl;
		total++;
	}
	else
	{
		powerset(set, tempSet, count + 1);
		strncat(tempSet, set + count, 1);
		powerset(set, tempSet, count + 1);
	}
}

int main()
{
	int count = 0;
	cin >> n;
	char *set = new char[n];
	char tempSet[100] = { '\0' };
	for (int i = 0; i < n; i++)
	{
		cin >> set[i];
	}
	total = 0;
	powerset(set, tempSet, count);
	cout << total;
	delete[]set;
	system("pause");
	return 0;
}