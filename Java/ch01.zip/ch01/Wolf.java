package cn.edu.seu.cose.javacourse.ch01;

public interface Wolf {
	
	void speak();

}
