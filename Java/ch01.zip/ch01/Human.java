package cn.edu.seu.cose.javacourse.ch01;

/**
 * @author Spark
 * This is a interface for human
 */
public interface Human {

	/**
	 *  This is a speak method
	 */
	void speak();
}
