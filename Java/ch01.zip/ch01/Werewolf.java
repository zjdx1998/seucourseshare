package cn.edu.seu.cose.javacourse.ch01;

public class Werewolf implements Wolf, Human{

	public void speak(){
		System.out.println("%^!%^$!&");
	}
}
