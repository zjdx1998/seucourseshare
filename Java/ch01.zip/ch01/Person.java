package cn.edu.seu.cose.javacourse.ch01;

public class Person {
	
	private String name;
	private int age;
	public int height;
	public int weight;
	
	public Person(String name, int age){
		this.name = name;
		this.age = age;
	}
	
	public void greet(){
		System.out.println("Hello, I am " + name 
				+ " , and I am " + age + " years old");
	}
	
	/*public String toString(){
		return name + " " + age;
	}*/
	
	public static void main(String[] args){
		Person tom = new Person("Tom", 0);	
		//Person jack = new Person();
		tom.greet();
		/*switch(tom.age){
			case(0): System.out.println("age = 0");
			case(10): System.out.println("age = 10");
		}*/
		
		//System.out.println(tom.toString());
		//System.out.println(args[1]);
		//System.out.print(args[0]);
		//for(int i=1; i<args.length; i++){
			//System.out.print(" " + args[i]);
		//}
		
		/*try{
			
		}finally{
			
		}*/
		//tom.greet();		
	}
}
