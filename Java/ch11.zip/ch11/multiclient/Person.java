package cn.edu.seu.cose.javacourse.ch11.multiclient;

public class Person {
	public static void main(String[] args){
		System.out.println("My name is Bill");
	}
}
