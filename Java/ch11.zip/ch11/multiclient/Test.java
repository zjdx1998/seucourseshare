package cn.edu.seu.cose.javacourse.ch11.multiclient;

import java.util.ArrayList;

public class Test<E extends   Comparable<E>> {

	public void sum(ArrayList<Object> l){
		
	}
	public static void main(String[] args){
		
		ArrayList<Number> a = new ArrayList<Number>();
		ArrayList<String> b = new ArrayList<String>();
		System.out.println(a.getClass());
		
		/*Test t = new Test();
		t.sum(new ArrayList<Object>());
		
		ArrayList<Number> a = new ArrayList<Number>();
		a.add(new Integer(10));*/
		
	}
}
