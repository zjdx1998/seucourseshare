package cn.edu.seu.cose.javacourse.ch11.simplechat;

import java.awt.*;
import javax.swing.*;

public class SimpleChatServer{
	JFrame frame;
	JTextArea textArea;
	JTextField textField;
	
	public void showUI(){
		frame = new JFrame("SimpleChatServer");
		frame.getContentPane().setLayout(new BorderLayout());
		textArea = new JTextArea();
		textField = new JTextField(35);
		JButton send = new JButton("send");
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		panel.add(textField); panel.add(send);
		frame.add(textArea, BorderLayout.CENTER);
		frame.add(panel, BorderLayout.SOUTH);
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public SimpleChatServer(){		
		showUI();
	}
	
	public static void main(String[] args){
		SimpleChatServer server = new SimpleChatServer();
		
	}

}
