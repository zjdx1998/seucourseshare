package cn.edu.seu.cose.javacourse.ch11;

import java.io.*;
import java.net.*;

public class WebTester {
	
	public static void main(String[] args){
		try{
			URL coseURL = new URL("http://cose.seu.edu.cn");
			URLConnection connection = coseURL.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String html = in.readLine();
			while(html!=null){
				System.out.println(html);
				html = in.readLine();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
