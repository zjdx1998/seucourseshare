package cn.edu.seu.cose.javacourse.ch11;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class GettingHostByIP {
	
	public static void main(String[] args){
		
		byte[] ip = {(byte)192, (byte)168, (byte)1, (byte)1};
		try{
			InetAddress i = InetAddress.getByAddress(ip);
			System.out.println(i.getHostName());
		}catch(UnknownHostException e){
			e.printStackTrace();
		}
	}
}
