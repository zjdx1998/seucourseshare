package cn.edu.seu.cose.javacourse.ch11;

import java.net.InetAddress;

public class MyPing {
	
	private static final int TIMEOUT = 10000;
	public void ping(InetAddress addr){
		try{
			String hostName = addr.getHostName();
			System.out.println(hostName);
			while(true){
				if(addr.isReachable(TIMEOUT)){
					System.out.println("Reply from "
						+ hostName + " within " + TIMEOUT + "ms.");
				}else{
					System.out.println("Cannot reply from "
							+ hostName + " within " + TIMEOUT + "ms.");
				}
				Thread.sleep(1000);
			}
		}catch(Exception e){e.printStackTrace();}		
	}
	
	public static void main(String[] args){
		MyPing ping = new MyPing();
		try{
			InetAddress addr = InetAddress.getByName("127.0.0.1");
			ping.ping(addr);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
