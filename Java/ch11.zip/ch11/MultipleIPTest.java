package cn.edu.seu.cose.javacourse.ch11;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class MultipleIPTest {
	
	public String getHostName(){
		try{
			InetAddress iAddress = InetAddress.getLocalHost();
			String hostName=iAddress.getHostName().toString();
			return hostName;
		}catch(UnknownHostException e){			
			e.printStackTrace();
			return "";
		}catch(Exception e){
			e.printStackTrace();
			return "";
		}
	}
	
	public ArrayList<String> getAllIP(){
		ArrayList<String> allIP = new ArrayList<String>();
		try{
			String hostName = getHostName();
			System.out.println(hostName);
			if(hostName.length()>0){
				InetAddress[] addresses = InetAddress.getAllByName(hostName);
				for(int i=0; i<addresses.length; i++){
					allIP.add(addresses[i].getHostAddress().toString());					
				}
			}
			return allIP;
		}catch(Exception e){
			e.printStackTrace();
			return allIP;
		}
	}
	
	public static void main(String[] args){
		MultipleIPTest test = new MultipleIPTest();
		System.out.println(test.getAllIP());
	}
}
