package cn.edu.seu.cose.javacourse.ch11;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class SingleIPTest {
	
	
	
	public void getIP(){
		
		try{
			//�õ�InetAddress
			InetAddress iAddress = InetAddress.getLocalHost();
			//��ñ���IP
			String localIP = iAddress.getHostAddress().toString();
			//��ñ�������
			String hostName=iAddress.getHostName().toString();
			System.out.println("����IPΪ: " + localIP);
			System.out.println("����������Ϊ: " + hostName);
		}catch(UnknownHostException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args){
		SingleIPTest test = new SingleIPTest();
		test.getIP();
	}

}
