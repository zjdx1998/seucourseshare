package cn.edu.seu.cose.javacourse.ch11;

import java.net.InetAddress;

public class AddressTest {
	
	public void printIP(){
		try{
			byte[] ip = {(byte)58,(byte)192,(byte)114,(byte)215};
			InetAddress addr = InetAddress.getByAddress(ip);
			String hostName = addr.getHostName();
			System.out.println(hostName);
		}catch(Exception e){
			e.printStackTrace();
		}		
	}
	
	public static void main(String[] args){
		AddressTest test = new AddressTest();
		test.printIP();
	}

}
