package cn.edu.seu.cose.javacourse.ch02;

public interface InterfaceA {
	
	public int methodA();
	int white = 0;

}
