package cn.edu.seu.cose.javacourse.ch02;

public class Eagle extends Bird{

	public int i = 0;
	
	public int fly(){
		return 10;
	}
}
