package cn.edu.seu.cose.javacourse.ch02;

public class CloneTest {
	
	
	public static void main(String[] args){
		Person tom = new Person("tom");
		Person jack = tom.clone();
		Person.changeName(jack);
		System.out.println(tom.name);
		//System.out.println(tom.getClass());
		System.out.println(tom);
	}
}
