package cn.edu.seu.cose.javacourse.ch02;

public interface InterfaceC extends InterfaceA, InterfaceB {
	int white = 10;
}
