package cn.edu.seu.cose.javacourse.ch02;

import java.io.File;


public class GeorgianHouse extends House{
	private String EavesStyle;
	public String name = "GeorgianHouse";
	public void showName(){
		System.out.println("The extended class is: " + name);
	}
	public GeorgianHouse(String door, String windows, String wall, String eaves){
		super(door, windows, wall);
		EavesStyle = eaves;
	}
	
	public void doorOpen(){
		super.doorOpen();
		System.out.println
			("Door opened outward");
	}
	// Getters and Setters goes here...
	
	public static void main(String[] args){		
		GeorgianHouse ghouse = new GeorgianHouse("a", "b", "c", "d");
		House house = ghouse;
		System.out.println(ghouse.name);
		System.out.println(house.name);
		ghouse.showName();
		house.showName();
		//((House)ghouse).showName();
		//System.out.println(((House)ghouse).name);
	}
}
