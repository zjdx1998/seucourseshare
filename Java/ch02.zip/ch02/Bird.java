package cn.edu.seu.cose.javacourse.ch02;

public  class Bird {
	public void fly(){
		
	}
	


}
