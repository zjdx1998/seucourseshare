package cn.edu.seu.cose.javacourse.ch02;

public interface InterfaceB extends InterfaceA{

	int methodB();
}
