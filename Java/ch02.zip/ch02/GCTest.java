package cn.edu.seu.cose.javacourse.ch02;

import java.util.ArrayList;

public class GCTest {

	public static void main(String[] args){
		Runtime run = Runtime.getRuntime();
		System.gc();
		System.out.println("Memoery: " + run.freeMemory());
		System.out.println("Creating houses...");
		ArrayList<House> area = new ArrayList<House>();
		for(int i=0; i<1000000; i++){
			area.add(new House());
		}		
		System.out.println("Memoery: " + run.freeMemory());
		System.out.println("There are " + area.size() + " houses");
		//System.out.println(area.isEmpty());
		System.out.println("Colleting garbage...");
		System.gc();
		System.out.println("Memoery: " + run.freeMemory());
		//System.out.println(area.isEmpty());
	}
}
