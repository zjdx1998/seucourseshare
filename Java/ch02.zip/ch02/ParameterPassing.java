package cn.edu.seu.cose.javacourse.ch02;

public class ParameterPassing {
	
	
	public static void changeInt(int innerInt){
		innerInt += 10;
	}
	
	public static void main(String[] args){
		int i = 5;
		ParameterPassing.changeInt(i);
		System.out.println(i);
	}
}
