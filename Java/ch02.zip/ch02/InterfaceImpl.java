package cn.edu.seu.cose.javacourse.ch02;

public class InterfaceImpl implements InterfaceC{

	@Override
	public int methodA() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodB() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public static void main(String[] args){
		System.out.println(InterfaceA.white);
	}

}
