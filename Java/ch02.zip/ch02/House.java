package cn.edu.seu.cose.javacourse.ch02;

public class House {
	private String doorStyle;
	private String windowsStyle;
	private String wallStyle;
	public String name = "House";
	
	public void showName(){
		System.out.println("This super class: " + name);		
	}
	
	public House(String door, String windows, String wall){
		doorStyle = door;
		windowsStyle = windows;
		wallStyle = wall;		
	}
	
	public House(){
		doorStyle = "";
		windowsStyle = "";
		wallStyle = "";
	}
	
	public String getDoorStyle() {
		return doorStyle;
	}
	public void setDoorStyle(String doorStyle) {
		this.doorStyle = doorStyle;
	}
	public String getWindowsStyle() {
		return windowsStyle;
	}
	public void setWindowsStyle(String windowsStyle) {
		this.windowsStyle = windowsStyle;
	}
	public String getWallStyle() {
		return wallStyle;
	}
	public void setWallStyle(String wallStyle) {
		this.wallStyle = wallStyle;
	}	
	
	protected void doorOpen(){
		System.out.println
		("Door opened inward");
	}
	
	
}
