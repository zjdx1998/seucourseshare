package cn.edu.seu.cose.javacourse.ch02;
interface IDemo
{
		int a =10;
		void fn();
}
class ADemo implements IDemo{

	@Override
	public void fn() {
		// TODO Auto-generated method stub
		
	}
	
}
public class demo extends ADemo{
    public void fn()
    {
			a=100;
    	}
    	void fn(int a)
   	 	{
			a=100;
    	}
}	
