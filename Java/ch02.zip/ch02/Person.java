package cn.edu.seu.cose.javacourse.ch02;

public class Person implements Cloneable {
	public String name;
	public Person(String name){
		this.name = name;
	}
	public static void changeName(Person person){
		person.name = "Jerry";
		person = null;
	}
	public static void main(String[] args){
		Person tom = new Person("Tom");
		
		Person.changeName(tom);
		System.out.println(tom==null);
		if(tom!=null){
			System.out.println(tom.name);
		}		
	}
	
	protected Person clone(){
		try{
			return (Person)(super.clone());
		}catch(Exception e){
			return null;
		}
	}
	
	public String toString(){
		return "A person with name " + this.name; 
	}
	
}
