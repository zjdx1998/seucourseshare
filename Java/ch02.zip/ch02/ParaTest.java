package cn.edu.seu.cose.javacourse.ch02;

public class ParaTest {
	public int a;
	public ParaTest(int a){
		this.a = a;
	}
	public static void changePrimitiveField(ParaTest t, int b){
		t.a = b;
		t = null;
	}
	public static void main(String[] args){
		ParaTest t = new ParaTest(10);
		ParaTest.changePrimitiveField(t, 90);
		System.out.println(t.a);
	}
}
