package cn.edu.seu.cose.javacourse.ch04;

import java.io.File;

public class FileTest2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File file = new File("c:\\\\text.txt");
		System.out.println(file.exists());

	}

}
