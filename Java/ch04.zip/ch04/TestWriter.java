package cn.edu.seu.cose.javacourse.ch04;

import java.io.*;

public class TestWriter {
	public static void main(String[] args) throws IOException{
		File file = new File("c:/text.txt");		
		FileWriter writer = new FileWriter(file,false);
		writer.write("CoSE".toCharArray());
		writer.write("����ѧԺ".toCharArray());
		writer.flush();
		FileReader reader = new FileReader(file);
		int character = reader.read();
		while(character!=-1){
			System.out.println((char)character);
			character = reader.read();
		}
	}
}
