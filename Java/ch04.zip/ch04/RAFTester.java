package cn.edu.seu.cose.javacourse.ch04;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RAFTester {
	public static void main(String[] args){
		try{
			RandomAccessFile raf = new RandomAccessFile(new File("c:/test.dat"), "rw");
			raf.seek(1);
			raf.writeByte(1);			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
