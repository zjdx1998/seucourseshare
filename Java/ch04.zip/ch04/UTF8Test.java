package cn.edu.seu.cose.javacourse.ch04;

import java.io.*;

public class UTF8Test {
	
	private File tempFile = new File("d:/utf8.dat");
	
	/** use existing file or create a new one
	 * @throws IOException
	 */
	public UTF8Test() throws IOException{
		if(!tempFile.exists()){
			try{
				tempFile.createNewFile();
			}catch(IOException e){
				throw e;
			}
		}
	}
	
	/**
	 *  test for UTF-8 usage
	 */
	public void test() throws IOException {
		try{
			FileInputStream fileInput = new FileInputStream(tempFile);
			InputStreamReader inputStrReader = new InputStreamReader(fileInput, "UTF-8");
		    BufferedReader buffereReader = new BufferedReader(inputStrReader);

		    FileOutputStream fileOutput = new FileOutputStream(tempFile);
		    PrintWriter fileWrite = new PrintWriter(new OutputStreamWriter(fileOutput, "UTF-8"));
		    BufferedWriter buffereWriter = new BufferedWriter(fileWrite);
		    
		    buffereWriter.append("hello, �ҽ�����");
		    buffereWriter.flush();
		    System.out.println(buffereReader.readLine());
		}catch(IOException e){
			throw e;
		}
       
	}
	
	public static void main(String[] args) throws IOException{
		UTF8Test test = new UTF8Test();
		test.test();
	}

}
