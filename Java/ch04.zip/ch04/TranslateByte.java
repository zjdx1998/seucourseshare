package cn.edu.seu.cose.javacourse.ch04;

import java.io.IOException;

public class TranslateByte {
    //int a = 0;
	public static void main(String[] args) throws IOException
    {
		
		TranslateByte tb = new TranslateByte();
		//System.out.println(tb.a);
		if(args.length<2){
        	System.err.println("Usage: Java TranslationByte FROM TO");
        	return;
        }
        byte from = (byte) args[0].charAt(0);
        byte to   = (byte) args[1].charAt(0);
        int b;
        System.out.print("Input the source: ");
        while ((b = System.in.read()) != -1)
            System.out.write(b == from ? to : b);
    }
}


