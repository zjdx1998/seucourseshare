package cn.edu.seu.cose.javacourse.ch04;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;

public class DirLister {	
	public void listDirectory(File file, FilenameFilter filter){		
		if(!file.exists()){
			System.out.println("Path Error.");
		}else if(file.isFile()){
			System.out.println("Not a directory.");
		}else{
			File[] files = file.listFiles(filter);
			System.out.println(files.length);
			Arrays.sort(files, new DescendingAlphabeticComparator());
			for(int i=0; i<files.length; i++){
				if(files[i].isFile()){
					System.out.println(files[i]);					
				}			
			}			
		}
	}
	
	public static void main(String[] args){
		DirLister lister = new DirLister();
		DirFilter filter = new DirFilter(".*log");
		lister.listDirectory(new File("c:/Windows"), filter);
	}

}
