package cn.edu.seu.cose.javacourse.ch04;

import java.io.*;
import java.nio.*;
import java.nio.channels.*;

public class MappedIO {
	private static File file = new File("d:/temp.tmp");
	private static int numOfBytes = 4000000;
//	private static int numOfUbuffInts = 200000;

	private abstract static class Tester {
		private String name;

		public Tester(String name) {
			this.name = name;
		}

		public long runTest() {
			System.out.print(name + ": ");
			try {
				long startTime = System.currentTimeMillis();
				test();
				long endTime = System.currentTimeMillis();
				return (endTime - startTime);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public abstract void test() throws IOException;
	}

	private static Tester[] tests = { new Tester("Stream Write") {
		public void test() throws IOException {
			DataOutputStream dos = new DataOutputStream(
					new BufferedOutputStream(new FileOutputStream(file)));
			for (int i = 0; i < numOfBytes; i++)
				dos.writeByte(i);
			dos.close();
		}
	}, new Tester("Mapped Write") {
		public void test() throws IOException {
			FileChannel fc = new RandomAccessFile(file, "rw")
					.getChannel();
			MappedByteBuffer mbb = fc.map(FileChannel.MapMode.READ_WRITE, 0, fc.size());
			for (int i = 0; i < numOfBytes; i++)
				mbb.put((byte)i);
			fc.close();
		}
	}, new Tester("Stream Read") {
		public void test() throws IOException {
			DataInputStream dis = new DataInputStream(new BufferedInputStream(
					new FileInputStream(file)));
			for (int i = 0; i < numOfBytes; i++)
				dis.readByte();
			dis.close();
		}
	}, new Tester("Mapped Read") {
		public void test() throws IOException {
			FileChannel fc = new FileInputStream(file)
					.getChannel();
			MappedByteBuffer mbb = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size());
			while (mbb.hasRemaining())
				mbb.get();
			fc.close();
		}
	}, new Tester("Stream Read/Write") {
		public void test() throws IOException {
			RandomAccessFile raf = new RandomAccessFile(file,
					"rw");
			raf.write(1);
			for (int i = 0; i < numOfBytes; i++) {
				raf.seek(raf.length() - 1);
				raf.write(raf.read());
			}
			raf.close();
		}
	}, new Tester("Mapped Read/Write") {
		public void test() throws IOException {
			FileChannel fc = new RandomAccessFile(file, "rw")
					.getChannel();
			MappedByteBuffer mbb = fc.map(FileChannel.MapMode.READ_WRITE, 0, fc.size());
			mbb.put((byte)0);
			for (int i = 1; i < numOfBytes; i++){
				mbb.put(mbb.get(i - 1));}
			fc.close();
		}
	} };

	public static void main(String[] args) {
		for (int i = 0; i < tests.length; i++)
			System.out.println(tests[i].runTest());
		try{
			FileChannel fc = new RandomAccessFile("temp.tmp", "rw").getChannel();
			MappedByteBuffer ib = fc.map(FileChannel.MapMode.READ_WRITE, 0, fc.size());
		}catch(Exception e){
			e.printStackTrace();
		}

	}
}
