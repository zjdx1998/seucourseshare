package cn.edu.seu.cose.javacourse.ch04;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;


public abstract class BufferBenchmark {
	
	private ArrayList<Integer> intStoreSource;
	private ArrayList<Integer> intStoreTarget;
	private final int MAX_STORE_SIZE = 500000;
	private File file;
	
	abstract void benchmark();
	
	public static int getRandomInt(){
		return (int)(Math.random()*255);
	}
	
	private void buildIntStore(){
		for(int i=0; i<MAX_STORE_SIZE; i++){
			intStoreSource.add(getRandomInt());
		}
	}
	
	public BufferBenchmark(File file){
		this.intStoreSource = new ArrayList<Integer>();
		this.intStoreTarget = new ArrayList<Integer>();
		this.buildIntStore();
		this.file = file;
	}
	
	public long run(int count){
		long beginTime = System.nanoTime();
		for(int i=0; i<count; i++){
			benchmark();
		}
		return System.nanoTime() - beginTime;
	}
}
