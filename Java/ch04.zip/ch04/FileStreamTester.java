package cn.edu.seu.cose.javacourse.ch04;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileStreamTester {
	
	private FileInputStream fis;
	private FileOutputStream fos;
	
	public FileStreamTester(File file) throws IOException{		
		createFile(file);
		this.fis = new FileInputStream(file);
		this.fos = new FileOutputStream(file, true);
				
	}
	
	public static void createFile(File file) throws IOException{
		if(!file.exists()||!file.isFile()){				
			file.createNewFile();
		}
	}
	
	public void close() throws IOException{
		fis.close();
		fos.close();
	}
	
	public int read() throws IOException{
		return fis.read();
	}
	
	public void write(int arg) throws IOException{
		fos.write(arg);
	}
	
	public void write(byte[] arg) throws IOException{
		fos.write(arg);
	}
	
	public int available() throws IOException{
		return fis.available();
	}	
	
	public static void main(String[] args){
		try {
			File file = new File("d:/test.dat");
			FileStreamTester tester = new FileStreamTester(file);
			tester.write(97);
			tester.write('b');
			tester.write(new String("����ѧԺ").getBytes());	
			
			System.out.println(tester.available() + " size");
			int i = tester.read();
			while (i != -1) {
				System.out.println((char)i);
				i = tester.read();
			}			
			tester.close();			
		}catch(IOException ex) {
			System.err.println(ex.toString());
		}
	}
}
