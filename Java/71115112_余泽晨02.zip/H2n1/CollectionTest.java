package H2n1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.Vector;

/**
 * @author 83849
 *����ArrayList,LinkedList,Vector��get,add,iterator,remove���������ܲ��
 */
/**
 * @author 83849
 *
 */
public class CollectionTest {
	private final int MAX_NUM=5000;
	private final int MAX_TIMES=20;
	private ArrayList<Integer> al=new ArrayList<Integer>();
	private LinkedList<Integer> ll=new LinkedList<Integer>();
	private Vector<Integer> vec=new Vector<Integer>();
	private Random random=new Random();

	/**
	 * ���캯��
	 */
	public CollectionTest() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * ��ArrayList���м����1000����
	 */
	void ALInsert(){
		for(int i=0;i<MAX_NUM;i++)
			al.add(al.size()/2,i);
	}

	/**
	 * ��ArrayList��ͷ���Ƴ�����Ԫ��
	 */
	void ALRemove(){
		while(al.size()>0)
			al.remove(0);	
	}

	/**
	 * �������1000��ArrayList
	 */
	void ALGet(){
		for(int i=0;i<MAX_NUM;i++)
			al.get(random.nextInt(MAX_NUM));
	}

	/**
	 * ��ȡArrayList�ĵ�����,������ȡ����Ԫ��
	 */
	void ALIterator(){
		Iterator<Integer> it=al.listIterator();
		for(int i=0;i<MAX_NUM;i++)
			it.next();
	}

	/**
	 * ��ArrayList��ͷ���Ƴ�����Ԫ��
	 */
	void LLInsert(){
		for(int i=0;i<MAX_NUM;i++)
			ll.add(ll.size()/2,i);
	}

	/**
	 * �������1000��LinkedList
	 */
	void LLRemove(){
		while(ll.size()>0)
			ll.remove(0);	
	}

	/**
	 * �������1000��LinkedList
	 */
	void LLGet(){
		for(int i=0;i<MAX_NUM;i++)
			ll.get(random.nextInt(MAX_NUM));
	}

	/**
	 * ��ȡLinkedList�ĵ�����,������ȡ����Ԫ��
	 */
	void LLIterator(){
		Iterator<Integer> it=ll.listIterator();
		for(int i=0;i<MAX_NUM;i++)
			it.next();
	}

	/**
	 * ��Vector���м����1000����
	 */
	void VecInsert(){
		for(int i=0;i<MAX_NUM;i++)
			vec.add(vec.size()/2,i);
	}

	/**
	 * ��Vector��ͷ���Ƴ�����Ԫ��
	 */
	void VecRemove(){
		while(vec.size()>0)
			vec.remove(0);	
	}

	/**
	 * �������1000��Vector
	 */
	void VecGet(){
		for(int i=0;i<MAX_NUM;i++)
			vec.get(random.nextInt(MAX_NUM));
	}

	/**
	 * ��ȡVector�ĵ�����,������ȡ����Ԫ��
	 */
	void VecIterator(){
		Iterator<Integer> it=vec.listIterator();
		for(int i=0;i<MAX_NUM;i++)
			it.next();
	}

	/**
	 * ����ArrayList,LinkedList,Vector��add,get,iterator,remove��ʱ��,�����
	 */
	void run(){
		long[] t1=new long[12];
		long[] t2=new long[12];
		long[] t=new long[12];

		System.gc();
		t1[0]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			ALInsert();
		}
		t2[0]=System.currentTimeMillis();
		
		t1[1]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			LLInsert();
		}
		t2[1]=System.currentTimeMillis();
		
		t1[2]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			VecInsert();
		}
		t2[2]=System.currentTimeMillis();
		
		t1[3]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			ALIterator();
		}
		t2[3]=System.currentTimeMillis();
		
		t1[4]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			LLIterator();
		}
		t2[4]=System.currentTimeMillis();
		
		t1[5]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			VecIterator();
		}
		t2[5]=System.currentTimeMillis();
		
		t1[6]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			ALGet();
		}
		t2[6]=System.currentTimeMillis();
		
		t1[7]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			LLGet();
		}
		t2[7]=System.currentTimeMillis();
		
		t1[8]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			VecGet();
		}
		t2[8]=System.currentTimeMillis();
		
		t1[9]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			ALRemove();
		}
		t2[9]=System.currentTimeMillis();
		
		t1[10]=System.currentTimeMillis();
		for(int j=0;j<MAX_TIMES;j++){
			LLRemove();
		}
		t2[10]=System.currentTimeMillis();
				
		t1[11]=System.currentTimeMillis();
		for(int j=0;j<MAX_NUM;j++){
			VecRemove();
		}
		t2[11]=System.currentTimeMillis();
		
		for(int i=0;i<12;i++)
			t[i]=t2[i]-t1[i];

		System.out.println("         Al    LL    Vec");
		for(int i=0;i<4;i++){					
			switch (i) {
			case 0:
				System.out.print("insert:  ");
				break;
			case 1:
				System.out.print("iterator:");
				break;
			case 2:
				System.out.print("get:     ");
				break;
			case 3:
				System.out.print("remove:  ");
				break;
			default:
				break;
			}
			for(int j=0;j<3;j++){
				System.out.print(t[i*3+j]+"    ");
			}
			System.out.println("");
		}
}

/**
 * @param args
 */
public static void main(String args[]){
	CollectionTest tester = new CollectionTest();
	tester.run();
}

}
