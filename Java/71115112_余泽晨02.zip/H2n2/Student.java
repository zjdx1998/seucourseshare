package H2n2;

import java.io.Serializable;

/**
 * @author 83849
 * ѧ����
 * �������ͳɼ��������ݳ�Ա
 * String name ����
 * double grade �ɼ�
 */
public class Student implements Serializable{

	private static final long serialVersionUID = 1L;
	
	/**
	 * ���캯��
	 * ��ʼ�������ͳɼ�
	 * @param name
	 * @param grade
	 */
	public Student(String name,double grade){
		setName(name);
		setGrade(grade);
	}
	
	private String name;
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	
	private double grade;
	
	/**
	 * @return the grade
	 */
	public double getGrade() {
		return grade;
	}
	/**
	 * @param grade the grade to set
	 */
	public void setGrade(double grade) {
		this.grade = grade;
	}
	
	
}
