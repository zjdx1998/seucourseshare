package cn.edu.seu.cose.javacourse.ch08;

public class InterruptDemo extends Thread{

	public void run(){
		System.out.println("Thread started");
		while(true){			
			try{
				System.out.println("Thread is running");
				Thread.sleep(1000);
			}catch(InterruptedException e){
				System.out.println("Interupped, and ended");
				return;
			}
		}
	}
	public static void main(String[] args){
		System.out.println("Main started");
		try{
			Thread t = new InterruptDemo();
			t.start();
			Thread.sleep(2000);
			t.interrupt();
		}catch(Exception e){}
		System.out.println("Main ended");
	}
}
