package cn.edu.seu.cose.javacourse.ch08;

import java.util.ArrayList;

public class WaitAndSleepDemo {
	
	public class MyTask implements Runnable{

		@Override
		public synchronized void run() {
			String name = Thread.currentThread().getName();
			System.out.println(name + " started.");
			try{
				//Thread.sleep(1000);
				wait(1000);
			}catch(Exception e){
				e.printStackTrace();
			}
			System.out.println(name + " ended.");			
		}		
	}
	
	public static void main(String[] args){
		long begin = System.currentTimeMillis();
		WaitAndSleepDemo test = new WaitAndSleepDemo();
		MyTask task = test.new MyTask();
		ArrayList<Thread> threadGroup = new ArrayList<Thread>();
		for(int i=0; i<10; i++){
			Thread t = new Thread(task, "Thread"+i);
			threadGroup.add(t);
			t.start();
		}
			
		for(int i=0; i<threadGroup.size(); i++){
			Thread t = threadGroup.get(i);
			try{
				t.join();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		System.out.println("time: " + (System.currentTimeMillis() - begin));
	}
}
