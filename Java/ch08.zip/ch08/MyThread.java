package cn.edu.seu.cose.javacourse.ch08;

public class MyThread extends Thread {

	public void run() {
		while (true) {
			System.out.println(this.getName()
					+ " is doing its own task");
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.setName("Thread1");
		myThread.start();
	}
}
