package cn.edu.seu.cose.javacourse.ch08;

public class ControlThreadDemo implements Runnable{
	public void run(){
		while(true){
			System.out.println("ha!");
			try{
				Thread.sleep(1000);
			}catch(Exception e){}
		}
	}
	
	public static void main(String[] args){
		Thread t1 = new Thread(new ControlThreadDemo());
		t1.start();
		try{
			t1.join(5000);
		}catch(Exception e){}
	}
}
