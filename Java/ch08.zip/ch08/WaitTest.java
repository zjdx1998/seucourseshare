package cn.edu.seu.cose.javacourse.ch08;

public class WaitTest {
	
	public StringBuffer isDownloaded = new StringBuffer("false");
	

	public class DisplayTask implements Runnable{
		public void run() {
			synchronized(isDownloaded){
				while(isDownloaded.toString().equals("false")){
					try{
						System.out.println("Displayer is waiting!");
						isDownloaded.wait();
					}catch(Exception e){
						e.printStackTrace();
					}
				}
				String name = Thread.currentThread().getName();
				System.out.println(name + " displayed this picture!");
			}						
		}		
	}
	
	private class DownloadTask implements Runnable{
		public void run() {
			String name = Thread.currentThread().getName();
			System.out.println(name + " is downloading a picture!");
			try{
				Thread.sleep(3000);
			}catch(Exception e){
				e.printStackTrace();
			}
			System.out.println(name + " completed the downloading a picture!");

			synchronized(isDownloaded){
				isDownloaded.replace(0, isDownloaded.length(), "true");
				isDownloaded.notifyAll();
			}			
		}		
	}
	
	public static void main(String[] args){
		WaitTest waitTest = new WaitTest();
		Thread displayThread = new Thread(waitTest.new DisplayTask(), "t1");
		Thread downloadThread = new Thread(waitTest.new DownloadTask(), "t2");		
		displayThread.start(); downloadThread.start();
	}

}
