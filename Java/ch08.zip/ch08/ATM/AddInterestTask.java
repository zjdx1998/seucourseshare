package cn.edu.seu.cose.javacourse.ch08.ATM;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class AddInterestTask implements Runnable{

	private static long PERIOD = 3000L;	
	private static double INTERESTRATIO = 0.05;
	private Timer timer;
	private TimerTask task;
	private HashMap<String, Account> accounts;
	
	public AddInterestTask(HashMap<String, Account> accounts){
		this.accounts = accounts;
		task = new MyTimerTask(); 
		timer = new Timer();		
	}
	
	private class MyTimerTask extends TimerTask{
		public void run(){			
			Set<String> keySet = accounts.keySet();
			for(String key: keySet){				
				Account account = accounts.get(key);
				double interestToBeAdded = account.getBalance() * INTERESTRATIO;
				account.setInterest(account.getInterest() + interestToBeAdded);
			}
		}		
	}
	
	public void run() {
		timer.schedule(task, PERIOD, PERIOD);		
	}
	
	public static void main(String[] args){
		Account tomAccount = new Account("Tom");
		tomAccount.deposit(100);
		Account JackAccount = new Account("Jack");
		JackAccount.deposit(10);
		HashMap<String, Account> accounts = new HashMap<String, Account>();
		accounts.put("Tom", tomAccount);
		accounts.put("Jack", JackAccount);
		AddInterestTask task = new AddInterestTask(accounts);
		Thread t = new Thread(task);
		t.start();
		while(true){
			System.out.println("tom balance: " + accounts.get("Tom").getBalance());
			System.out.println("jack balance: " + accounts.get("Jack").getBalance());
			System.out.println("-------------------");
			try{
				Thread.sleep(1000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}
