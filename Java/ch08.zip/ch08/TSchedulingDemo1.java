package cn.edu.seu.cose.javacourse.ch08;

public class TSchedulingDemo1 implements Runnable{

	public void run(){		
		for(int i=0; i<10; i++){
			String name = Thread.currentThread().getName();
			System.out.println(name + "is running.");
			try{
				Thread.sleep(1000);
			}catch(Exception e){}
		}		
	}
	
	public static void main(String[] args){
		Runnable myTask = new TSchedulingDemo1();
		Thread t1 = new Thread(myTask);
		t1.setName("t1");
		t1.setPriority(5);
		Thread t2 = new Thread(myTask);
		t2.setName("t2");
		t2.setPriority(5);
		t1.start();t2.start();
	}
}
