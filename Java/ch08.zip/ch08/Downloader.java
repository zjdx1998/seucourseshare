package cn.edu.seu.cose.javacourse.ch08;

public class Downloader extends Thread{

    public PingPong(String whatToSay, int delayTime) {
        word = whatToSay;
        delay = delayTime;
    }

    public void run() {
        try {
            while(true){
                System.out.print(word + " ");
                Thread.sleep(delay); // wait until next time
            }
        } catch (InterruptedException e) {
            return;             // end this thread
        }
    }
    public static void main(String[] args) {
        new PingPong("ping",  1000).start(); // 1/3 second
        new PingPong("PONG", 2000).start(); // 1 second
    }

	

}
