package cn.edu.seu.cose.javacourse.ch08;

public class YieldDemo extends Thread{
	public void run(){
		for(int i=0; i<100; i++){
			System.out.print("t");
		}
	}
	public static void main(String[] args){
		System.out.println("main started");
		try{
			Thread t = new YieldDemo();
			t.start();
			//Thread.yield();
			
		}catch(Exception e){}
		System.out.println("main ended");
	}

}
