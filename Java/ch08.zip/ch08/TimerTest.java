package cn.edu.seu.cose.javacourse.ch08;

import java.util.Timer;
import java.util.TimerTask;

public class TimerTest {	
	
	Timer timer;
	public static long PERIOD = 1000L;
	public class AddInterestTask extends TimerTask{

		
		public void run() {
			System.out.println("$100 added.");
			
		}		
	}
	
	public class greetTask extends TimerTask{

		public long period = 10000/12L;
		public void run() {
			System.out.println("Hello");			
		}		
	}
	
	public TimerTest(){
		timer = new Timer();		
		timer.schedule(new AddInterestTask(), 0, PERIOD);
	}
	
	public static void main(String[] args){
		TimerTest test = new TimerTest();		
	}
}
