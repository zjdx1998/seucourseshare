package cn.edu.seu.cose.javacourse.ch08;

public class EndThreadDemo extends Thread{
	public void run(){		
		while(!interrupted()){
			System.out.println("Thread is running");
		}
		System.out.println("Thread interruped and ended");
	}
	
	public static void main(String[] args){
		Thread t = new EndThreadDemo();
		t.start();
		try{
			Thread.sleep(10);
		}catch(Exception e){}
		t.interrupt();		
	}
}
