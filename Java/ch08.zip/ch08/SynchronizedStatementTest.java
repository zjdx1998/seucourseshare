package cn.edu.seu.cose.javacourse.ch08;

public class SynchronizedStatementTest {
	public static int[] values = {10, 11, 12};
	
	public static void abs(int[] values){
		System.out.println(Thread.currentThread().getName() + " is going to do abs!");
		synchronized(values){
			System.out.println(Thread.currentThread().getName() + " is doing abs!");

			for(int i=0; i<values.length; i++){
				values[i] = 0;
			}
			try{
				Thread.sleep(10000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		System.out.println(Thread.currentThread().getName() + " is leaving abs!");

	}
	
	public class MyTask implements Runnable{
		public void run() {
			String name = Thread.currentThread().getName();
			System.out.println(name + " is running");
			while(true){
				abs(values);
			}
		}		
	}
	
	public static void main(String[] args){
		SynchronizedStatementTest test = new SynchronizedStatementTest();
		Runnable myTask = test.new MyTask();
		Thread t1 = new Thread(myTask, "t1");
		Thread t2 = new Thread(myTask, "t2");
		t1.start();t2.start();
	}

}
