package H3n1;

import javax.swing.UIManager;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * @author 83849
 * 计算器
 */
public class Calculator extends JFrame{
	private final String[] KEYS={"7","8","9","/","x²","4","5","6",
			"*","sqrt(x)","1","2","3","+","%","+/-","0",".","-","="};

	private JButton keys[]=new JButton[KEYS.length];

	/** 计算器上的功能键的显示名字 */  
	private final String[] COMMAND = { "BackSpace", "CE", "C" };  

	/** 计算器上的功能键的按钮 */  
	private JButton commands[] = new JButton[COMMAND.length];  

	/** 计算结果文本框 */  
	private JTextField resultText = new JTextField("0");  

	/**
	 * @author 83849
	 *当前状态的枚举值
	 */
	private enum SIGN{LEFT,OPERATION,RIGHT};

	/**
	 * 当前状态
	 */
	private SIGN sign=SIGN.LEFT;

	// 计算的中间结果。  
	private double resultNum = 0.0;  

	// 当前计算的运算符  
	private String lastOperator = null;

	/** 
	 * 构造函数 
	 */  
	public Calculator() {  
		super();  
		// 初始化计算器  
		init();  

		// 设置计算器的背景颜色  
		this.setBackground(Color.LIGHT_GRAY);  
		this.setTitle("计算器");  
		// 在屏幕(500, 300)坐标处显示计算器  
		this.setLocation(500, 300);  
		// 不许修改计算器的大小  
		this.setResizable(false);  

		// 使计算器中各组件大小合适  
		this.pack();  

		//显示计算器
		this.setVisible(true);

		//设置关闭操作
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}  

	/** 
	 * 初始化计算器 
	 */  
	private void init() {  
		// 文本框中的内容采用右对齐方式  
		resultText.setHorizontalAlignment(SwingConstants.RIGHT);  
		// 不允许修改结果文本框  
		resultText.setEditable(false);  
		// 设置文本框背景颜色为白色  
		resultText.setBackground(Color.white);  

		// 初始化计算器上键的按钮，将键放在一个画板内  
		JPanel keysPanel = new JPanel();  
		// 用网格布局器，4行，5列的网格，网格之间的水平方向间隔为3个象素，垂直方向间隔为3个象素  
		keysPanel.setLayout(new GridLayout(4, 5, 3, 3));  
		for (int i = 0; i < KEYS.length; i++) {  
			keys[i] = new JButton(KEYS[i]);  
			keys[i].setSize(40, 40);
			keys[i].setForeground(Color.blue);  
			keysPanel.add(keys[i]);  
		}  
		// 运算符键用红色标示，其他键用蓝色表示  
		keys[3].setForeground(Color.red);  
		keys[4].setForeground(Color.red);  
		keys[8].setForeground(Color.red);  
		keys[9].setForeground(Color.red);  
		keys[13].setForeground(Color.red);  
		keys[14].setForeground(Color.red);
		keys[15].setForeground(Color.red);  
		keys[18].setForeground(Color.red);  
		keys[19].setForeground(Color.red);  

		// 初始化功能键，都用红色标示。将功能键放在一个画板内  
		JPanel commandsPanel = new JPanel();  
		// 用网格布局器，1行，3列的网格，网格之间的水平方向间隔为3个象素，垂直方向间隔为3个象素  
		commandsPanel.setLayout(new GridLayout(1, 3, 3, 3));  
		for (int i = 0; i < COMMAND.length; i++) {  
			commands[i] = new JButton(COMMAND[i]);  
			commandsPanel.add(commands[i]);  
			commands[i].setForeground(Color.red);  
		}  


		// 新建一个大的画板，将上面建立的command和keys画板放在该画板内  
		JPanel panel1 = new JPanel();  

		// 画板采用边界布局管理器，画板里组件之间的水平和垂直方向上间隔都为3象素  
		panel1.setLayout(new BorderLayout(3, 3));  

		panel1.add("North", commandsPanel);   
		panel1.add("West", keysPanel);  

		// 建立一个画板放文本框  
		JPanel top = new JPanel();  
		top.setLayout(new BorderLayout());  

		// 将文本框放在北部
		top.add("Center", resultText);  

		// 整体布局  
		getContentPane().setLayout(new BorderLayout(3, 5));  
		getContentPane().add("North", top);  
		getContentPane().add("Center", panel1);  

		//添加菜单栏
		JMenuBar menubar=new JMenuBar();
		JMenu help=new JMenu("帮助");
		JMenu edit=new JMenu("编辑");
		JMenuItem about=new JMenuItem("关于");
		JMenuItem clean=new JMenuItem("清空");
		about.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(getContentPane(), "help");
			}
		});
		clean.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new CalculatorListener().handleC();
			}
		});
		help.add(about);
		edit.add(clean);
		menubar.add("West",help);
		menubar.add(edit);
		setJMenuBar(menubar);


		// 为各按钮添加事件侦听器  
		for (int i = 0; i < KEYS.length; i++) {  
			keys[i].addActionListener(new CalculatorListener());  
		}  
		for (int i = 0; i < COMMAND.length; i++) {  
			commands[i].addActionListener(new CalculatorListener());  
		}  
	} 

	/**
	 * @author 83849
	 * 设置各个按键的触发后的事件
	 */
	private class CalculatorListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub

			// 获取事件源的标签  
			String label = e.getActionCommand();  
			if (label.equals(COMMAND[0])) {  
				// 用户按了"Backspace"键  
				handleBackspace();  
			} else if (label.equals(COMMAND[1])) {  
				// 用户按了"CE"键  
				if(resultText.getText().equals("除数不能为0")||resultText.getText().equals("NaN")){
					handleC();
					return;
				}
				resultText.setText("0");  
			} else if (label.equals(COMMAND[2])) {  
				// 用户按了"C"键  
				handleC();  
			} else if ("0123456789.".indexOf(label) >= 0) {  
				// 用户按了数字键或者小数点键  
				handleNumber(label);    
			} else {  
				// 用户按了运算符键  
				handleOperator(label);  
			}  
		}


		/**
		 * @param label 当前操作符
		 *  处理操作符
		 */
		private void handleOperator(String label) {
			// TODO Auto-generated method stub

			if(lastOperator==null)
				resultNum=getNumber();

			//更新操作符
			if(sign==SIGN.OPERATION&&"+-*/".indexOf(label)>=0){
				lastOperator=label;
				return;
			}

			//二元运算符的处理
			if(lastOperator!=null){
				if(lastOperator.equals("/")){
					if(getNumber()==0.0){
						resultText.setText("除数不能为0");
						keys[3].setEnabled(false);  
						keys[4].setEnabled(false);  
						keys[8].setEnabled(false);  
						keys[9].setEnabled(false);  
						keys[13].setEnabled(false);  
						keys[14].setEnabled(false);
						keys[15].setEnabled(false);  
						keys[18].setEnabled(false);  
						keys[19].setEnabled(false);  
						return;
					}else{
						resultNum/=getNumber();
						lastOperator=null;
					}
				}else if(lastOperator.equals("+")){
					resultNum+=getNumber();
					lastOperator=null;
				}else if(lastOperator.equals("-")){
					resultNum-=getNumber();
					lastOperator=null;
				}else if(lastOperator.equals("*")){
					resultNum*=getNumber();
					lastOperator=null;
				}
			}

			lastOperator=label;
			
			//一元运算符的处理
			if(label.equals("+/-")){
				resultNum=resultNum*(-1);
				sign=SIGN.RIGHT;
				lastOperator=null;
			}else if(label.equals("x²")){
				resultNum=resultNum*resultNum;
				sign=SIGN.RIGHT;
				lastOperator=null;
			}else if(label.equals("sqrt(x)")){
				if(resultNum<0){
					keys[3].setEnabled(false);  
					keys[4].setEnabled(false);  
					keys[8].setEnabled(false);  
					keys[9].setEnabled(false);  
					keys[13].setEnabled(false);  
					keys[14].setEnabled(false);
					keys[15].setEnabled(false);  
					keys[18].setEnabled(false);  
					keys[19].setEnabled(false);  
				}
				resultNum=Math.sqrt(resultNum);
				sign=SIGN.RIGHT;
				lastOperator=null;
			}else if(label.equals("%")){
				resultNum=resultNum/100;
				sign=SIGN.RIGHT;
				lastOperator=null;
			}else if(label.equals("=")){
				sign=SIGN.RIGHT;
				lastOperator=null;
			}


			//若结果为整数则输出整数,否则输出小数
			if(sign==SIGN.RIGHT){
				long t1;  
				double t2;  
				t1 = (long) resultNum;  
				t2 = resultNum - t1;  
				if (t2 == 0) {  
					resultText.setText(String.valueOf(t1));  
				} else {  
					resultText.setText(String.valueOf(resultNum));  
				} 
			}

			//更新当前状态
			sign=SIGN.OPERATION;
		}

		//将文本框中的文本转化为数字
		private double getNumber() {
			// TODO Auto-generated method stub
			double result=0;
			try{
				result=Double.valueOf(resultText.getText());
			}catch(NumberFormatException e){
				e.printStackTrace();
			}
			return result;
		}

		//处理数字键和小数点的显示
		private void handleNumber(String label) {
			// TODO Auto-generated method stub

			if(resultText.getText().equals("除数不能为0")||resultText.getText().equals("NaN")){
				handleC();
			}

			//清空文本并更新状态
			if(sign==SIGN.OPERATION){
				resultText.setText("0");
				sign=SIGN.RIGHT;
			}
			String text=resultText.getText();

			if(label.equals(".")&&!text.contains(".")&&text.length()>0)
				resultText.setText(text+label);
			else if(!label.equals(".")&&text.equals("0"))
				resultText.setText(label);
			else if(!label.equals("."))
				resultText.setText(text+label);
		}

		/**
		 * 设置C键按下后触发的事件
		 */
		private void handleC() {
			// TODO Auto-generated method stub
			// 初始化计算器的各种值  
			if(resultText.getText().equals("除数不能为0")||resultText.getText().equals("NaN")){
				keys[3].setEnabled(true);  
				keys[4].setEnabled(true);  
				keys[8].setEnabled(true);  
				keys[9].setEnabled(true);  
				keys[13].setEnabled(true);  
				keys[14].setEnabled(true);
				keys[15].setEnabled(true);  
				keys[18].setEnabled(true);  
				keys[19].setEnabled(true);  
			}

			resultText.setText("0");  
			sign = SIGN.LEFT;  
			lastOperator=null;
		}


		/**
		 * 设置Backspace键按下后触发的事件
		 */
		private void handleBackspace() {
			// TODO Auto-generated method stub
			String text=resultText.getText();
			
			if(text.equals("除数不能为0")||resultText.getText().equals("NaN")){
				handleC();
				return;
			}
			int i=text.length();
			if(i>1)
				resultText.setText(text.substring(0, i-1));
			else if(i==1)
				resultText.setText("0");
		}

	}

	public static void main(String[] args){

		//设置皮肤
		try {		
			//javax.swing中自带的皮肤
			//						UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");

			//JTattoo.jar包中的皮肤
			javax.swing.UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		}catch (Exception e)
		{
			e.printStackTrace();    
		}

		Calculator calculator=new Calculator();
	}
}