package cn.edu.seu.cose.javacourse.ch07;

import java.awt.event.*;

import javax.swing.*;

public class HelloWorldSwing {
	public static void main(String[] args) {
        long memory = 0L;
        long time = 0L;
        memory = Runtime.getRuntime().freeMemory();
        time = System.currentTimeMillis();
        JFrame frame = new JFrame();
        JLabel label = new JLabel();
        label.setText("Hello World!");
        frame.add(label);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
               public void windowClosing(WindowEvent we) {
                      System.exit(0);
               }
        });
        frame.pack();
        System.out.print("Time:");
        System.out.println(System.currentTimeMillis() - time);
        System.out.print("Memory:");
        System.out.println(memory - Runtime.getRuntime().freeMemory());
	}
}
