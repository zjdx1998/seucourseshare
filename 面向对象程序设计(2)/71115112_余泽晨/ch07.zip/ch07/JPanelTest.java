package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;

import javax.swing.*;

public class JPanelTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		JFrame f = new JFrame("JPanel example");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container cp = f.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JPanel p1 = new JPanel();
		p1.setBackground(Color.green);
		cp.add(p1);
		
		JPanel p2 = new JPanel();
		p2.setBackground(Color.blue);
		cp.add(p2);

		p1.add(new JTextField("����"));
		p1.add(new JButton("��ť"));

		f.setSize(200, 200);
		f.setVisible(true);
	}
}
