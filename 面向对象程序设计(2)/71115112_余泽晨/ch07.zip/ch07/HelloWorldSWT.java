package cn.edu.seu.cose.javacourse.ch07;

import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;

public class HelloWorldSWT {
	public static void main(String[] args) {
		long memory = 0L;
		long time = 0L;
		memory = Runtime.getRuntime().freeMemory();
		time = System.currentTimeMillis();
		Display display = new Display();
		Shell shell = new Shell(display);
		Label label = new Label(shell, SWT.NONE);
		label.setText("Hello World!");
		shell.pack();
		label.pack();
		shell.open();
		System.out.print("Time:");
		System.out.println(System.currentTimeMillis() - time);
		System.out.print("Memory:");
		System.out.println(memory - Runtime.getRuntime().freeMemory());
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
		label.dispose();
	}

}
