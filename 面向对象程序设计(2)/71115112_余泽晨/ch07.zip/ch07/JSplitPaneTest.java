package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;

import javax.swing.*;

public class JSplitPaneTest {
	
	public static void main(String[] args) 
	{
		JFrame f = new JFrame("JSplitPanel example");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container cp = f.getContentPane();
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		p1.add(new JTextField("TextField"));
		p2.add(new JButton("Button"));
		//JTextField jtf = new JTextField("TextField");
		JSplitPane sp1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, p1, p2);
		sp1.setDividerLocation(80);
		cp.add(sp1);
		f.setSize(200, 200);
		f.setVisible(true);
	}
}
