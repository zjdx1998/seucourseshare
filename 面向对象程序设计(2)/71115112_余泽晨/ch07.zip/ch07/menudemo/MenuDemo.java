package cn.edu.seu.cose.javacourse.ch07.menudemo;

import java.awt.event.*;
import javax.swing.*;

/**һ���򵥵���ʾJMenuBar/JMenu/JMenuItem������
 * @author Spark
 *
 */
public class MenuDemo {
	JMenuBar menuBar;

	/**
	 * ����MenuBar
	 */
	public void buildMenuBar(){
		//����MenuBar
		menuBar = new JMenuBar();
		
		//����MenuBar�е�һ��File Menu
		JMenu menuFile = new JMenu("File");
		menuBar.add(menuFile);
		String [] sFileMenus = {"Open", "Save", "Close"};
		JMenuItem menuFileTemp = null;
		for (int i = 0; i < sFileMenus.length; i++) {
			menuFileTemp = new JMenuItem(sFileMenus[i]);
			menuFileTemp.setActionCommand(sFileMenus[i]);
			menuFileTemp.addActionListener(new MenuListener());
			menuFile.add(menuFileTemp);
		}

		//����MenuBar�е�һ��Option Menu��������RadioButton�͵�Item
		JMenu menuOption = new JMenu("Option");
		menuBar.add(menuOption);
		String [] sColorMenus = {"Red", "Green", "Blue"};
		JRadioButtonMenuItem menuColorTemp = null;
		ButtonGroup bgColor = new ButtonGroup();
		for (int i = 0; i < sFileMenus.length; i++) {
			menuColorTemp = new JRadioButtonMenuItem(sColorMenus[i]);
			menuColorTemp.setActionCommand(sColorMenus[i]);
			menuColorTemp.addActionListener(new MenuListener());
			menuOption.add(menuColorTemp);
			bgColor.add(menuColorTemp);
		}

		//��Option�˵�������һ���ָ���
		menuOption.add(new JSeparator());

		//�ڷָ��ߺ��������CheckBox�͵�Item
		String [] sControlMenus = {"Red", "Green", "Blue"};
		JCheckBoxMenuItem menuControlTemp = null;
		for (int i = 0; i < sFileMenus.length; i++) {
			menuControlTemp = new JCheckBoxMenuItem(sControlMenus[i]);
			menuControlTemp.setActionCommand(sControlMenus[i]);
			menuControlTemp.addActionListener(new MenuListener());
			menuOption.add(menuControlTemp);
		}
	}

	/**���ڼ����˵���������ļ�����
	 * @author Spark
	 *
	 */
	private class MenuListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e){
			String command = e.getActionCommand();
			if (command.equals("Open")){
				// do something here...
			}else if(command.equals("Save")){
				// do something here...
			}else if(command.equals("Close")){
				// do something here...
			}else if (command.equals("Red")) {
				// do something here...
			}else if (command.equals("Green")) {
				// do something here...
			}else if (command.equals("Blue")) {
				// do something here...
			}else if (command.equals("TextField")) {
				// do something here...
			}else if (command.equals("RadioButton")) {
				// do something here...
			}else if (command.equals("CheckBox")) {
				// do something here...
			}else if (command.equals("Button")) {
				// do something here...
			}
		}
	}
	
	/**
	 * ���췽��
	 */
	public MenuDemo(){
		JFrame frame = new JFrame("Menu Demo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.buildMenuBar();
		//��menuBar��Ϊframe�Ĳ˵���
		frame.setJMenuBar(this.menuBar);
		frame.setSize(400, 400);
		frame.setVisible(true);		
	}

	public static void main(String[] args){		
		MenuDemo demo = new MenuDemo();
	}
}
