package cn.edu.seu.cose.javacourse.ch07.menudemo;

import java.awt.event.*;
import javax.swing.*;

/**һ���򵥵�Popup�˵�����
 * @author Spark
 *
 */
public class PopupDemo {

	public PopupDemo() {
		JFrame frame = new JFrame("PopupDemo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel jp = new JPanel();
		JButton button = new JButton("Button");
		button.addMouseListener(new PopupListener());
		jp.add(button);
		frame.add(jp);
		frame.setSize(100, 100);
		frame.setVisible(true);
	}

	/**���ڼ�������һ��¼��ļ�����
	 * @author Spark
	 *
	 */
	private class PopupListener implements MouseListener {

		/* ֻ��������һ������
		 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
		 */
		@Override
		public void mouseClicked(MouseEvent e){
			//MouseEvent.BUTTON3��ʾ����Ҽ����
			if (e.getButton() == MouseEvent.BUTTON3){
				JPopupMenu popupMenu = new JPopupMenu();
				JMenuItem menuItem1 = new JMenuItem("Operation one");
				JMenuItem menuItem2 = new JMenuItem("Operation two");
				popupMenu.add(menuItem1);
				popupMenu.add(menuItem2);
				//��Popup�˵���ʾ����Ļ��ǰλ�ã���JButton����ͬһλ�ã�
				popupMenu.show(e.getComponent(), e.getX(), e.getY());
			}
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// Nothing to do
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// Nothing to do
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// Nothing to do
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// Nothing to do
		}

	}

	public static void main(String[] args) {
		PopupDemo demo = new PopupDemo();
	}
}
