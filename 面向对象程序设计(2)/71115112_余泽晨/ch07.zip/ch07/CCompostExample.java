package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;

import javax.swing.*;

public class CCompostExample {

	private Component initLeft() {
		JPanel panelLeft = new JPanel();
		panelLeft.setLayout(new FlowLayout(FlowLayout.CENTER));
		panelLeft.add(new JButton("open"));
		panelLeft.add(new JButton("save"));
		panelLeft.add(new JButton("close"));
		panelLeft.add(new JButton("exit"));

		return panelLeft;
	}
	
	private Component initRight() {
		JPanel panelRight = new JPanel();
		panelRight.setLayout(new GridLayout(5, 1));

		JPanel panelTemp = null;
		for (int i = 0; i < 5; i++) {
			panelTemp = new JPanel();
			panelTemp.setLayout(new FlowLayout(FlowLayout.LEFT));
			panelTemp.add(new JLabel("Label " + i));
			panelTemp.add(new JTextField("TextField " + i));
			panelRight.add(panelTemp);
		}

		return panelRight;
	}
	public static void main(String[] args) {
		JFrame f = new JFrame("Composed Layout example");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		CCompostExample compost = new CCompostExample();
		JSplitPane splitPanel = new JSplitPane();
		splitPanel.setLeftComponent(compost.initLeft());
		splitPanel.setRightComponent(compost.initRight());
		splitPanel.setDividerLocation(80);
		f.add(splitPanel);

		f.setSize(400, 200);
		f.setVisible(true);
	}

}
