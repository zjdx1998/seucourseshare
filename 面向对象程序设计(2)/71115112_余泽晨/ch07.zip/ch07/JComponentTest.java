package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;
import javax.swing.*;


public class JComponentTest {

	public static void main(String[] args){
		JFrame frame = new JFrame("Hello");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		JPanel jp = new JPanel();
		JTextField tf = new JTextField("text field");
		Graphics g = tf.getGraphics();
		g.drawLine(0, 0, 10, 10);
		jp.add(tf);
		cp.add(jp);
		frame.setSize(200,200);
		frame.setVisible(true);		
	}
}
