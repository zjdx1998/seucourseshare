package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;

import javax.swing.*;

public class CompositeDemo {
	public static void main(String[] args){
		JFrame frame = new JFrame("CompositeDemo");
		frame.getContentPane().setLayout(new BorderLayout());
		JToolBar bar = new JToolBar();
		bar.add(new JButton("Open"));
		bar.add(new JButton("Close"));
		frame.add(bar, BorderLayout.NORTH);
		JTree tree = new JTree();
		//tree.
		frame.add(tree, BorderLayout.WEST);
		JSplitPane pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		String[] data = {"one", "two", "three", "four"};
		JList myList = new JList(data);
		JScrollPane scrollPane = new JScrollPane();		
		JTextArea textArea = new JTextArea();
		scrollPane.add(textArea);
		textArea.setEditable(false);
		pane.add(myList, JSplitPane.TOP);
		pane.add(scrollPane,JSplitPane.BOTTOM);
		frame.add(pane,BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);
		frame.setVisible(true);
	}

}
