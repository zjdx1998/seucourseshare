package cn.edu.seu.cose.javacourse.ch07.layout;

import java.awt.*;

import javax.swing.*;

public class AnotherGridLayoutDemo {
	
	public static void main(String[] args){
		JFrame frame = new JFrame();
		frame.getContentPane().setLayout(new GridLayout(2, 2));
		frame.add(new JLabel("Username"));
		frame.add(new JTextField());
		frame.add(new JLabel("Password"));
		frame.add(new JPasswordField());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(200, 200);
		frame.setVisible(true);
		
		
	}

}
