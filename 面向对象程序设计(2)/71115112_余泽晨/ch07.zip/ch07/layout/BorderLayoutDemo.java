package cn.edu.seu.cose.javacourse.ch07.layout;

import java.awt.*;
import javax.swing.*;

public class BorderLayoutDemo {
	public static void main(String[] args) {
		JFrame frame = new JFrame("BorderLayoutDemo");
		frame.getContentPane().setLayout(
				new BorderLayout());
		JButton button1 = new JButton("center");
		JButton button2 = new JButton("east");
		JButton button3 = new JButton("south");
		JButton button4 = new JButton("west");
		JButton button5 = new JButton("north");
		frame.add(button1, BorderLayout.CENTER);
		frame.add(button2,BorderLayout.EAST);
		frame.add(button3, BorderLayout.SOUTH);
		frame.add(button4, BorderLayout.WEST);
		frame.add(button5, BorderLayout.NORTH);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 300);
		frame.setVisible(true);
	}

}
