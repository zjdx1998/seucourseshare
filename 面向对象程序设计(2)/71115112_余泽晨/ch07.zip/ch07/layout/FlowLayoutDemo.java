package cn.edu.seu.cose.javacourse.ch07.layout;

import java.awt.*;
import javax.swing.*;

public class FlowLayoutDemo {
	public static void main(String[] args) {
		JFrame frame = new JFrame("FlowLayoutDemo");
		frame.getContentPane().setLayout(
				new FlowLayout(FlowLayout.RIGHT));
		JButton button1 = new JButton("OK");
		JButton button2 = new JButton("Open");
		JButton button3 = new JButton("Close");
		frame.add(button1);
		frame.add(button2);
		frame.add(button3);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 100);
		frame.setVisible(true);
	}

}
