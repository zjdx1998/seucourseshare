package cn.edu.seu.cose.javacourse.ch07;

import javax.swing.*;

/**
 * ������ʵ��
 * @author ��� jdk5.0
 */
public class CalculatorFrame extends JFrame {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public CalculatorFrame() {
        setTitle("������");
        CalculatorPanel panel = new CalculatorPanel();
        add(panel);
        pack();
    }

    public static void main(String[] args) {
        CalculatorFrame frame = new CalculatorFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}