package cn.edu.seu.cose.javacourse.ch07.listenerdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class TextDemo {

	JFrame frame;
	JTextArea text;
	
	private class TextChangeListener implements DocumentListener{

		boolean changed = false;
		@Override
		public void changedUpdate(DocumentEvent e) {
			if(!changed){
				frame.setTitle("*" + frame.getTitle());
				changed = true;
			}						
		}

		@Override
		public void insertUpdate(DocumentEvent e) {
			if(!changed){
				frame.setTitle("*" + frame.getTitle());
				changed = true;
			}			
		}

		@Override
		public void removeUpdate(DocumentEvent e) {
			if(!changed){
				frame.setTitle("*" + frame.getTitle());
				changed = true;
			}			
		}			
	}
	
	public TextDemo(){
		frame = new JFrame();
		frame.setTitle("hello.txt");
		text = new JTextArea();
		text.getDocument().addDocumentListener(new TextChangeListener());
		frame.add(text);		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 200);
		frame.setVisible(true);
	}	
	
	public static void main(String[] args){
		TextDemo demo = new TextDemo();
	}
}
