package cn.edu.seu.cose.javacourse.ch07.listenerdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MouseDemo {
	
	private class ButtonListener implements MouseListener{
		
		public void mouseClicked(MouseEvent e){			
			textField.setText("Button clicked");			
		}
		public void mouseEntered(MouseEvent e){			
			textField.setText("Button enterd");			
		}
		public void mouseExited(MouseEvent e){
			textField.setText("Button exited");
		}
		public void mousePressed(MouseEvent e){
			textField.setText("Button pressed");
		}
		public void mouseReleased(MouseEvent e){
			textField.setText("Button released");
		}
		
	}
	
	private JTextField textField;

	

	public static void main(String[] args) {
		MouseDemo first = new MouseDemo();
		first.show();
	}
	
	public void show() {
		JFrame f = new JFrame("Event example");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container cp = f.getContentPane();
		cp.setLayout(new FlowLayout());

		textField = new JTextField();
		textField.setColumns(18);
		cp.add(textField);

		JButton btn = new JButton("Click");
		cp.add(btn);
		btn.addMouseListener(new ButtonListener());

		f.setSize(300, 100);
		f.setVisible(true);
	}
	
	
}
