package cn.edu.seu.cose.javacourse.ch07.listenerdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ActionDemo{	
		
	private JTextField textField;
	
	private class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
		textField.setText("Button clicked");			
		}
	}
	
	public ActionDemo(){
		JFrame frame = new JFrame("Event example");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new FlowLayout());
		textField = new JTextField();
		textField.setColumns(18);
		frame.add(textField);
		JButton btn = new JButton("Click");
		frame.add(btn);
		btn.addActionListener(new ButtonListener());
		frame.setSize(300, 100);
		frame.setVisible(true);
	}	

	public static void main(String[] args) {
		ActionDemo demo = new ActionDemo();
	}		
}


