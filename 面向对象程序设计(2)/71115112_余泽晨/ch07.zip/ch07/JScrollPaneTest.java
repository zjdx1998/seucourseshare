package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;

import javax.swing.*;

public class JScrollPaneTest {

	public static void main(String[] args) 
	{
		JFrame f = new JFrame("JSplitPanel example");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container cp = f.getContentPane();
		
		JPanel j1 = new JPanel();
		j1.add(new JTextArea(3,10));
		//JTextArea ja = new JTextArea(3,10);

		JScrollPane sp = new JScrollPane(j1);
		sp.setVerticalScrollBarPolicy(
			JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		cp.add(sp);

		f.setSize(200, 200);
		cp.setBackground(Color.WHITE);
		f.setVisible(true);
	}

}
