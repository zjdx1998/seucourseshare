package cn.edu.seu.cose.javacourse.ch07;

import java.awt.*;
import java.awt.event.*;

public class HellowWorldAWT {
	public static void main(String[] args) {
		long memory = 0L;
		long time = 0L;
		memory = Runtime.getRuntime().freeMemory();
		time = System.currentTimeMillis();
		Frame frame = new Frame();
		Label label = new Label();
		label.setText("Hello World!");
		frame.add(label);
		frame.setVisible(true);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
		frame.pack();
		System.out.println(System.currentTimeMillis() - time);
		System.out.println(memory - Runtime.getRuntime().freeMemory());
	}
}
