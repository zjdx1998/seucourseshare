package cn.edu.seu.cose.javacourse.ch07.paneltest;

import java.awt.Color;
import java.awt.*;

import javax.swing.*;

public class PanelTest {
	
	public static void main(String[] args){
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(0, 0, 200, 200);
		frame.getContentPane().setLayout(null);
		
		JPanel p1 = new JPanel(null);
		JPanel p2 = new JPanel(null);
		JPanel p3 = new JPanel(null);
		p1.setBounds(10, 10, 60, 60);
		p1.setBackground(Color.blue);
		p2.setBounds(10, 80, 60, 110);
		p2.setBackground(Color.red);
		p3.setBounds(80, 10, 110, 180);
		p3.setBackground(Color.yellow);
		frame.add(p1);
		frame.add(p2);
		frame.add(p3);
//		/frame.setSize(200,300);
//		/frame.pack();
		frame.setVisible(true);		
	}
}
