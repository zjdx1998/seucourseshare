package cn.edu.seu.cose.javacourse.ch07.textselection;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.plaf.basic.BasicBorders;
import javax.swing.plaf.metal.MetalBorders;

public class TextSelectionPanel extends JPanel{
	
	JTextArea textArea; //Դ�����
	JTextField textField; //Ŀ�������
	JButton copyToButton; //������ť
	
	
	/**���췽��
	 * 
	 */
	public TextSelectionPanel(){
		this.setLayout(new FlowLayout());
		this.setName("inner panel");
		textArea = new JTextArea(5,20);
		textArea.setBorder(BasicBorders.getTextFieldBorder());
		//textArea.setBorder(BasicBorders.getTextFieldBorder());		
		textField = new JTextField(20);
		textField.setEditable(false);
		copyToButton = new JButton("CopyTO");
		copyToButton.addActionListener(new CopyActionListener());
		this.add(textArea);
		this.add(copyToButton);
		this.add(textField);
	}
	
	/**�����¼��ļ�����
	 * @author Spark
	 *
	 */
	private class CopyActionListener implements ActionListener{
		public void actionPerformed(ActionEvent event){
			//textField.setText("");
			String selected = textArea.getSelectedText();
			textField.setText(selected);
		}
	}
}
