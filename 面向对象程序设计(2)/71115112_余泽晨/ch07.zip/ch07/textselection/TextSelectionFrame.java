package cn.edu.seu.cose.javacourse.ch07.textselection;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**��һ��TextArea��ѡ�������ֿ�������һ��TextField��
 * @author Spark
 *
 */
public class TextSelectionFrame extends JFrame{
	
	/**���췽��
	 * 
	 */
	public TextSelectionFrame(){		
		TextSelectionPanel panel = new TextSelectionPanel();
		this.setTitle("Copy Selected Text");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.add(panel);
		this.setSize(600,200);		
	}	
	
	public static void main(String[] args){
		TextSelectionFrame frame = new TextSelectionFrame();
		frame.setVisible(true);
	}
}
