package cn.edu.seu.cose.javacourse.ch07.quiz;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class QuizPanel extends JPanel{
	
	
	JLabel question;
	JRadioButton a,b,c,d;
	ButtonGroup quizGroup;
	JButton submit;
	
	public QuizPanel(){
		
		question = new JLabel("��JVM�����ڴ�����Ϊ�̶���500M����ȷд���ǣ�");
		a = new JRadioButton("-Xms500m -Xmx500m");
		b = new JRadioButton("-Xms 500m -Xmx 500m");
		c = new JRadioButton("-Xms-500m -Xmx-500m");
		d = new JRadioButton("-Xms:500m -Xmx:500m");
		quizGroup = new ButtonGroup();
		quizGroup.add(a);quizGroup.add(b);
		quizGroup.add(c);quizGroup.add(d);
		submit = new JButton("�ύ");
		submit.setSize(50, 50);
		submit.addActionListener(new SubmitListener());
		
		this.setLayout(new GridLayout(6,1));
		this.add(question);	
		this.add(a);this.add(b);this.add(c);this.add(d);
		this.add(submit);
	}
	
	private class SubmitListener implements ActionListener{
		public void actionPerformed(ActionEvent event){
			if(a.isSelected()){
				JOptionPane.showMessageDialog(submit, "��ȷ");				
			}else{
				JOptionPane.showMessageDialog(submit, "����");
				//String result = JOptionPane.showInputDialog("Please input your name:");
				//int result = JOptionPane.showConfirmDialog(submit,"Select your answer:");				
			}
		}
	}
}
