package cn.edu.seu.cose.javacourse.ch07.timer;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * <p>
 * File: StopWatch.java
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * <a href="http://www.bioz.info/">BIOZ.info</a> Copyright (c) 2004
 * </p>
 * 
 * @author <a href="mailto:chancewang78@hotmail.com">Chance</a>
 */
public class StopWatch extends JFrame {
	JButton btnStart, btnStop;
	JLabel label;
	Timer timer;

	public StopWatch() {
		label = new JLabel("00:00:00.000");
		btnStart = new JButton("start");
		btnStop = new JButton("stop");
		final int delay = 100;
		final Date startTime = new Date();
		final SimpleDateFormat sdf = new SimpleDateFormat(
				"HH:mm:ss.S");
		final Action taskPerformer = new AbstractAction() {
			public void actionPerformed(ActionEvent evt) {
				// ��ʾʱ��
				Date d = new Date(System
						.currentTimeMillis()
						- startTime.getTime() - 28800000);
				label.setText(sdf.format(d));
				label.repaint();
			}
		};
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				startTime.setTime(new Date().getTime());
				timer = new Timer(delay, taskPerformer);
				timer.start();
			}
		});
		btnStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if (timer != null && timer.isRunning())
					timer.stop();
			}
		});

		Container c = getContentPane();
		c.add(label, BorderLayout.NORTH);
		c.add(btnStart, BorderLayout.CENTER);
		c.add(btnStop, BorderLayout.SOUTH);
	}

	public static void main(String[] args) {

		javax.swing.SwingUtilities
				.invokeLater(new Runnable() {
					public void run() {
						createAndShowGUI();
					}
				});

	}

	private static void createAndShowGUI() {
		StopWatch window = new StopWatch();
		window
				.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.pack();
		window.setVisible(true);
	}
}