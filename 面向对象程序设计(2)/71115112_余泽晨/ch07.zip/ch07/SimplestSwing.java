package cn.edu.seu.cose.javacourse.ch07;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.*;

public class SimplestSwing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		JButton button = new JButton("Click me");
		//button.setEnabled(false);
		Container pane = frame.getContentPane();
		
		pane.add(button);
		frame.setSize(300,300);
		frame.setVisible(true);
	}

}
