package H1n1;

import java.io.File;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * A class listing files matching the filter by last modfied time and printing.
 * 
 * @author yzc
 */
public class DirLister implements IDirLister{

	Scanner scan;

	/**
	 *���캯��,��ʼ��scan. 
	 */
	DirLister(){
		scan=new Scanner(System.in);
	}	

	/**
	 * չʾ�˵�,��ȡ����.
	 * @exception InputMismatchException
	 * if an error occured,input a paramter again
	 */
	public void menu(){
		System.out.println("������Ҫ���ҵ�Ŀ¼");
		File file;
		String dir;
		while (true) {			
			dir=scan.nextLine();
			file=new File(dir);
			if(!file.exists()){
				System.out.println("Path Error!");
			}else if(!file.isDirectory()){
				System.out.println("Not a Directory!");			
			}else{
				break;
			}
		}
		System.out.println("������Ҫ���ҵĺ�׺��");
		String key=scan.nextLine();
		key=".*?\\."+key+"$";
		DirFilter filter=new DirFilter(key);
		System.out.print("�������ļ�����ʽ:\n1:����\n2:����\n");	
		int order=0;
		while(true){
			try{
				order=scan.nextInt(3);
			}
			catch(InputMismatchException e)
			{
				System.out.println("������1��2\n");
				String del=scan.nextLine();
			}
			if(order==0)
				System.out.println("������1��2\n");
			else
				break;
		}
		listDir(file,filter,new DirComparator(),order);
	}

	
	/* (non-Javadoc)
	 * @see H1n1.IDirLister#listDir(java.io.File, H1n1.DirFilter, H1n1.DirComparator, int)
	 */
	public void listDir(File file,DirFilter filter,DirComparator comparator,int order){						
		File[] files=file.listFiles(filter);				
		Arrays.sort(files, new DirComparator());
		if(0==files.length)
		{
			System.out.println("�Ҳ�����ƥ����ļ�");
			return;
		}
		if(order==1){
			for(int i=0;i<files.length;i++){
				if(files[i].isFile()){					
					System.out.println(files[i]);	
				}
			}
		}
		else{
			for(int i=files.length-1;i>=0;i--){
				if(files[i].isFile()){
					System.out.println(files[i]);	
				}				
			}
		}
	}

	/**
	 * @param  args
	 */
	public static void main(String args[]){
		DirLister lister=new DirLister();
		lister.menu();
	}
}
