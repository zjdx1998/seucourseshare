package H1n1;

import java.io.File;
import java.io.FilenameFilter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A class creating a filter for filename
 * 
 * For example:
 * DirFilter filter=new DirFilter("jpg")
 * 
 * @author 83849
 *
 */
public class DirFilter implements FilenameFilter{
	
	String regex;
	
	/**
	 * ���캯��.
	 * @param key �ļ���ƥ��ĺ�׺��
	 */
	public DirFilter(String key) {
		// TODO Auto-generated constructor stub
		regex=key;
	}
	
	/* (non-Javadoc)
	 * @see java.io.FilenameFilter#accept(java.io.File, java.lang.String)
	 */
	public boolean accept(File dir,String name){
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(name);
		return m.find();
	}
}
