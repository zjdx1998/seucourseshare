package H1n1;

import java.io.File;
import java.util.Comparator;

/**
 * A class creating a comparator for files'last modified time
 * 
 * @author 83849
 *
 */
public class DirComparator implements Comparator<File>{
	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	public int compare(File dir1,File dir2){
		if(dir1.lastModified()>dir2.lastModified())
			return 1;
		else
			return -1;
	}
}
