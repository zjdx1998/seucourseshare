package cn.edu.seu.cose.javacourse.ch05;

import java.util.*;

public class ForEachTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] array = new int[]{1,2,3};
		Collection<Integer> list = new ArrayList<Integer>();
		Set<Integer> set = new HashSet<Integer>();
		for(int i=2; i>=0; i--){
			set.add(i+1);
		}
		for(int i=0; i<3; i++){
			list.add(i+1);
		}
		for(int i:array){
			System.out.println(i);
		}
		for(int i:list){
			System.out.println(i);
		}
		for(int i:set){
			System.out.println(i);
		}
		
		

	}

}
