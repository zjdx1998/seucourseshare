package cn.edu.seu.cose.javacourse.ch05;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapTest {

	public static void main(String[] args){
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(71108501, "Tom"); //����
		map.put(71108502, "Mike"); //����
		map.put(71108503, "Peter"); //����
		String name = map.get(71108502); //����
		//map.remove(71108503);//ɾ��
		Set<Integer> keySet = map.keySet(); //��ȡ���е�key
		Collection<String> valueSet = map.values(); //��ȡ���е�value
		Set<Entry<Integer, String>> entrySet = map.entrySet(); //��ȡ���е�entry
		
		// ����Entry
		Iterator<Entry<Integer, String>> t = entrySet.iterator();
		while(t.hasNext()){
			Entry<Integer, String> e = t.next();
			System.out.print(e.getKey() + " ");
			System.out.println(e.getValue());
		}
		
		// ��һ�ֱ�����ʽ
		Iterator<Integer> it = map.keySet().iterator();
		while(it.hasNext()){
			Integer key = it.next();
			String value = map.get(key);
			System.out.println("Key:" + key + " Value:" + value);
		}		
	}
}
