package cn.edu.seu.cose.javacourse.ch05;

import java.util.*;

public class ListPerformance {
	private static int reps = 10000;
	private static int quantity = 1000;

	private abstract static class Tester {
		private String name;

		Tester(String name) {
			this.name = name;
		}

		abstract void test(List<String> a);
	}

	private static Tester[] tests = { new Tester("get") {
		void test(List<String> a) {
			for (int i = 0; i < reps; i++) {
				for (int j = 0; j < quantity; j++)
					a.get(j);
			}
		}
	}, new Tester("iteration") {
		void test(List<String> a) {
			for (int i = 0; i < reps; i++) {
				Iterator<String> it = a.iterator();
				while (it.hasNext())
					it.next();
			}
		}
	}, new Tester("insert") {
		void test(List<String> a) {
			int half = a.size() / 2;
			String s = "test";
			for (int i = 0; i < reps*10; i++)
				a.add(half,s);
		}
	}, new Tester("remove") {
		void test(List<String> a) {
			while(!a.isEmpty()){
				a.remove(0);
			}
		}
	}, };
	
	public static void fill(List<String> a){
		for(int i =0; i<quantity; i++){
			a.add("test");
		}
	}

	public static void test(List<String> a) {
		System.out.println("Testing "
				+ a.getClass().getName()); 
		for (int i = 0; i < tests.length; i++) {
			fill(a);
			System.out.print(tests[i].name);
			long t1 = System.currentTimeMillis();
			tests[i].test(a);
			long t2 = System.currentTimeMillis();
			System.out.println(": " + (t2 - t1));
		}
	}

	public static void testArrayAsList(int reps) {
		System.out.println("Testing array as List");
		// Can only do first two tests on an array:
		for (int i = 0; i < 2; i++) {
			String[] sa = new String[quantity];
			Arrays.fill(sa, "test");
			List<String> a = Arrays.asList(sa);
			System.out.print(tests[i].name);
			long t1 = System.currentTimeMillis();
			tests[i].test(a);
			long t2 = System.currentTimeMillis();
			System.out.println(": " + (t2 - t1));
		}
	}

	public static void main(String[] args) {
		System.out.println(reps + " repetitions");
		testArrayAsList(reps);
		test(new ArrayList<String>());
		test(new LinkedList<String>());

	}
} 

