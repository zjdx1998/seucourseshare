package cn.edu.seu.cose.javacourse.ch10;

import java.sql.*;

public class MySQLTest {
	Connection connection;
	Statement statement;
	ResultSet rs;

	public void query() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/" +
					"MyDB?user=root&password=Patrick";
			Class.forName("com.mysql.jdbc.Driver"); // ���ؼ�ע��JDBC��������
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			String sqlQuery = "select date " +
					"from bookstore";
			rs = statement.executeQuery(sqlQuery);
			while (rs.next()) {
				System.out.println(rs.getDate("date"));
			}
		} catch (ClassNotFoundException e) {
			System.out.println("�޷��ҵ�������");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				statement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void queryUsingRSMetadata() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/" +
					"MyDB?user=root&password=Patrick";
			Class.forName("com.mysql.jdbc.Driver"); // ���ؼ�ע��JDBC��������
			connection = DriverManager.getConnection(dbURL);
			statement = connection.createStatement();
			String sqlQuery = "select * from bookstore";
			rs = statement.executeQuery(sqlQuery);
			ResultSetMetaData rsmd = rs.getMetaData();
			StringBuffer buffer = new StringBuffer();
			int spaceCounter = 0;
			for(int i=1; i<=rsmd.getColumnCount(); i++){
				String columnName = rsmd.getColumnName(i);
				spaceCounter += columnName.length();
				buffer.append(columnName + "\t");
				if(i!=rsmd.getColumnCount()){
					spaceCounter += getTabSpace(columnName.length());
				}
			}	
			
			buffer.append("\n");
			for(int i=0; i<spaceCounter; i++){
				buffer.append("-");
			}
			buffer.append("\n");			
			while (rs.next()) {
				//buffer.append(rs.getInt("store_id") + "\t\t");
				buffer.append(rs.getString("store_name") + "\t\t");
				buffer.append(rs.getInt("sales") + "\t");
				buffer.append(rs.getDate("date") + "\t");
			}
			System.out.println(buffer);
			
		} catch (ClassNotFoundException e) {
			System.out.println("�޷��ҵ�������");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				statement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private int getTabSpace(int length) {
		System.out.println("tab:" + (8 - (length % 8)));
		return 8 - (length % 8);
		
	}

	public void tabTest(){
		StringBuffer buffer = new StringBuffer();
		buffer.append("1111111\t222");
		buffer.append("\n--------------------------");
		System.out.println(buffer);
	}

	public static void main(String[] args) {
		MySQLTest demo = new MySQLTest();
		//demo.tabTest();
		demo.queryUsingRSMetadata();
		//demo.query();
	}
}
