package h4n1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BookStore {
	private static final Object[] ColLenth = null;
	Connection connection = null;
	Statement statement = null;
	String sql=null;
	final String TABLE="book_store";	
	String insertSql="insert into "+TABLE+" values (?,?,?)";
	PreparedStatement pstmt=null;

	public BookStore(){
		final String DATABASE="bookstore";
		final String url="jdbc:mysql://localhost/";
		final String username="root";
		final String password="root";
		
		ResultSet rs=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection(url+"test",username,password);			
			statement=connection.createStatement();
			sql="create database if not exists "+DATABASE;
			statement.executeUpdate(sql);
			connection=DriverManager.getConnection(url+DATABASE,username,password);
			statement=connection.createStatement();
			sql="create table if not exists "+TABLE
					+ "(store_name varchar(16) not null,"
					+ "Sales int not null,"
					+ "Date datetime not null)";
			statement.executeUpdate(sql);
			pstmt=connection.prepareStatement(insertSql);
			
			sql="select * from "+TABLE;
			rs=statement.executeQuery(sql);
			if(!rs.next())
				Insert();
			
		}catch(ClassNotFoundException e){
			System.out.println("�޷��ҵ�������");
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void Insert(){
		String[] names={"Los Angeles","San Diego","Los Angeles","Boston"};
		int[] sales={1500,250,300,700};
		String[] date={"1999-01-09","1999-01-07","1999-01-08","1999-01-08"};
		try {
			for(int i=0;i<names.length;i++){
				pstmt.setString(1, names[i]);
				pstmt.setInt(2, sales[i]);
				pstmt.setString(3, date[i]);
				pstmt.addBatch();
				pstmt.clearParameters();
			}
			pstmt.executeBatch();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("��������ʧ��");
			e.printStackTrace();
		}finally{
			try {
				pstmt.clearBatch();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}

	public void Print(){
		sql="select * from "+TABLE;
		ResultSet rs=null;
		ResultSetMetaData rsma=null;
		try {
			rs=statement.executeQuery(sql);
			rsma=rs.getMetaData();
			int length=rsma.getColumnCount();
			ArrayList<Integer> colLength=new ArrayList<Integer>();
			for(int i=1;i<=length;i++){
				System.out.print(rsma.getColumnName(i)+'\t');
				colLength.add((rsma.getColumnName(i).length()/8+1)*8);
			}
			colLength.set(length-1, rsma.getColumnName(length).length());
			System.out.print('\n');
			for(int i=0;i<rsma.getColumnCount();i++){
				for(int j=0;j<colLength.get(i);j++)
				System.out.print('-');
			}
			System.out.print("\n");
			colLength.set(length-1, (rsma.getColumnName(length).length()/8+1)*8);
			for(int i=0;rs.next();i++){
				System.out.printf("%-"+colLength.get(0)+"s", rs.getString(1));
				System.out.printf("%-"+colLength.get(1)+"s", rs.getString(2));
				System.out.printf("%-"+colLength.get(2)+"s", rs.getString(3).substring(0, 10)+'\n');	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	public void disConnect(){
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args){
		BookStore bookstore=new BookStore();
		bookstore.Print();
		bookstore.disConnect();
	}
}
