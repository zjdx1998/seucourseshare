package cn.edu.seu.cose.javacourse.ch03;

import java.io.IOException;

import cn.edu.seu.cose.javacourse.ch01.Person;

public class PersonException {
	
	public void getShape(Person p) 
		throws IOException{
		double ratio = p.height / p.weight;
		// Calculate and print the body shape of Person p
	}
	
	public static void main(String[] args){
		PersonException e = new PersonException();
		Person tom = new Person("tom",18);
		tom.height = 180;
		tom.weight = 0;
		try{
			e.getShape(tom);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
