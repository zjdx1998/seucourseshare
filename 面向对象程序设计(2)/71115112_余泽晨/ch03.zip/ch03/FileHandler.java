package cn.edu.seu.cose.javacourse.ch03;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileHandler {
	
	public void readFile(File file) {
		try{
			FileInputStream fis = new FileInputStream(file);
		}catch(IOException e){
			System.out.println(e);
		}		
	}
	
	public void checkFile(File file) throws IOException, IllegalArgumentException{
		if(!file.exists()){
			throw new IOException("File doesn't exist!");
		}else{
			throw new IllegalArgumentException("Not a file!");
		}
	}
	
/*	public void test(File file){
		try{
			this.checkFile(file);
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}*/
	
	/*public void test(File file){
		try{
			this.checkFile(file);			
		}catch(IOException e){
			System.out.println(e.getMessage());
		}catch(IllegalArgumentException e){
			System.out.println("Please provide a file");
		}catch(Exception e){
			System.out.println("Other exceptions occur");
		}finally{
			file.delete();
		}
	}	*/
	
	public void test(File file){
		try{
			this.checkFile(file);			
		}catch(IOException e){
			e.printStackTrace();
		}catch(IllegalArgumentException e){
			throw e;
		}catch(Exception e){
			System.out.println("Other exceptions occur");
		}finally{
			file.delete();
		}
	}
	
	public static void main(String[] args){
		FileHandler h = new FileHandler();
		h.test(new File("c:/hello.txt"));
	}
}
