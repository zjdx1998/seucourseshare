package cn.edu.seu.cose.javacourse.ch03;

import java.io.File;
import java.io.IOException;

public class ExceptionTest2 {
	
	public void checkFile(File file) throws Exception{
		throw new 
	}
	
	public void test(File file){
		try{
			this.checkFile(file);			
		}catch(IOException e){
			System.out.println(e.getMessage());
		}catch(IllegalArgumentException e){
			throw e;
		}catch(Exception e){
			System.out.println("Other exceptions occur");
		}finally{
			file.delete();
		}
}

}
