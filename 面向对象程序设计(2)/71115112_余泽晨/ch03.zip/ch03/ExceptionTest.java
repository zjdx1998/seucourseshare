package cn.edu.seu.cose.javacourse.ch03;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class ExceptionTest {

	public void test() throws Exception{
		try{
			throw new IOException();
		}finally{
			throw new NullPointerException();
		}
	}
	
	public static void main(String[] args) throws IOException {
		/*ExceptionTest t = new ExceptionTest();		
			try{
				t.test();
			}catch(Exception e){
				e.printStackTrace();
			}*/	
		
		
			FileOutputStream writer = new FileOutputStream("c:\temp.dat");
		
		
		
	}
}
