package cn.edu.seu.cose.javacourse.ch03;

public class SubException extends SuperException{
	public void foo(){
		System.out.println("subException");
	}
	
	public static void main(String[] args){
		SubException e = new SubException();
		e.foo();
	}

}
