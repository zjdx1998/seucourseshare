package cn.edu.seu.cose.javacourse.ch03;

public class SuperException {

	public void foo() throws Exception{
		throw new Exception();
	}
}
