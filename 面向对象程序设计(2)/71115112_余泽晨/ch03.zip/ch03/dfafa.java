package cn.edu.seu.cose.javacourse.ch03;

public class dfafa {
	
	public static void main(String[] args){
		String a = "1";
		String b = "1";
		System.out.println(a==b);
	}

}
