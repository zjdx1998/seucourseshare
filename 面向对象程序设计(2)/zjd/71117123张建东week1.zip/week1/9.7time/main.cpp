#include "mytime.h"
#include "mytime.cpp"

int main(){
    Time A(23,12,04);
    A.print_std();
    A.tick();
    A.print_std();
    Time B(23,12,59);
    B.tick();
    B.print_std();
    Time C(23,59,59);
    C.print_std();
    C.tick();
    C.print_std();
    return 0;
}