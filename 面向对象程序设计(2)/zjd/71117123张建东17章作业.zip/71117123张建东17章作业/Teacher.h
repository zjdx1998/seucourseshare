#ifndef TEACHER_H
#define TEACHER_H

#include "BaseProperty.h"

class Teacher : public BaseProperty{
public:
    Teacher(istream& input):BaseProperty("Teacher",input){
        init(input);
    }
    virtual void init(istream&);
    virtual void output(ostream&);
    void setSchool(const string& s);
    string getSchool() const;
    void setDomain(const string& d);
    string getDomain() const;
    void setCourse(const string& c);
    string getCourse() const;
private:
    string school,domain,course;
};

void Teacher::init(istream& input){
    string s,d,c;
    input>>s>>d>>c;
    setSchool(s);setDomain(d);setCourse(c);
}

void Teacher::output(ostream& out){
    BaseProperty::output(out);
    out<<"Belong to : "<<school<<"\nSkilled in : "<<domain<<"\nTeach the"<<course<<endl;
    out<<"======================================================\n"<<endl;
}

void Teacher::setSchool(const string& s){
    school = s;
}
string Teacher::getSchool() const{
    return school;
}
void Teacher::setDomain(const string& d){
    domain = d;
}
string Teacher::getDomain() const{
    return domain;
}
void Teacher::setCourse(const string& c){
    course = c;
}
string Teacher::getCourse() const{
    return course;
}

#endif
