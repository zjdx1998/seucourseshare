#ifndef  ASSISTANT_H
#define ASSISTANT_H

#include "BaseProperty.h"

class Assistant : public BaseProperty{
public:
    Assistant(istream& input):BaseProperty("Assistant",input){
        init(input);
    }
    virtual void init(istream&);
    virtual void output(ostream&);
    void setProject(const string &p);
    string getProject() const;
private:
    string project;
};

void Assistant::init(istream& input){
    string p;
    input>>p;
    setProject(p);
}

void Assistant::output(ostream& out){
    BaseProperty::output(out);
    out<<"The assistant's project is "<<project<<endl;
    out<<"======================================================\n"<<endl;
}

void Assistant::setProject(const string &p){
    project = p;
}
string Assistant::getProject() const{
    return project;
}
#endif
