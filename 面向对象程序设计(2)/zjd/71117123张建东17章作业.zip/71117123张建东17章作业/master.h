#ifndef  MASTER_H
#define MASTER_H

#include "BaseProperty.h"

class Master : public BaseProperty{
public:
    Master(istream& input):BaseProperty("Master",input){
        init(input);
    }
    virtual void init(istream&);
    virtual void output(ostream&);
    void setProject(const string& p);
    string getProject() const;
    void setCourse(const string& c);
    string getCourse() const;
    void setMajor(const string& m);
    string getMajor() const;
private:
    string major,project,course;
};

void Master::init(istream& input){
    string m,p,c;
    input>>m>>p>>c;
    setMajor(m);setProject(p);setCourse(c);
}

void Master::output(ostream& out){
    BaseProperty::output(out);
    out<<"Major is : "<< major<<"\nMaster Project is : "<<project<<"\nStudy the course : "<<course<<endl;
    out<<"======================================================\n"<<endl;
}

void Master::setProject(const string &p){
    project = p;
}
string Master::getProject() const{
    return project;
}

void Master::setCourse(const string &c){
    course = c;
}
string Master::getCourse() const{
    return course;
}

void Master::setMajor(const string &m){
    major = m;
}
string Master::getMajor() const{
    return major;
}

#endif
