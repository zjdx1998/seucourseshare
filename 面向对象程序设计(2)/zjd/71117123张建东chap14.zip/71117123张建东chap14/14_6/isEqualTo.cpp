#include<bits/stdc++.h>
using namespace std;

template<typename T>
bool isEqualTo(T& a,T& b){
    return (a==b);
}


class point{
public:
    point(double x,double y):x(x),y(y){}
    bool operator == (const point & right){
        return ((this->x==right.x) && (this->y==right.y));
    }
private:
    double x,y;
};

int main(){
    cout<<"Test the fundamental type here:"<<endl;
    char a='a',b='a';
    cout<<"a-b is equal to " << isEqualTo(a,b)<<endl;
    int c=1,d=1;
    cout<<"c-d is equal to " << isEqualTo(c,d)<<endl;
    point A(5,6.3),B(6.3,5);
    cout<<"Now test the user-modified class here:"<<endl;
    cout<<"If we didn't overloading the operator == , we would compile error"<<endl;
    cout<<"the result of 'A is equal to B' is " << (bool)isEqualTo(A,B)<<endl;
    return 0;
}