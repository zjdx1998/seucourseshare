#include "Array.h"
#include<cstdio>

int main(){
    cout<<"Please input five numbers"<<endl;
    Array<int> A(5);
    cin>>A;
    cout<<"Here are five numbers that you inputed just now"<<endl;
    cout<<A;
    cout<<endl;
    cout<<"Here we have a B from A"<<endl;
    Array<int> B(A);
    if(B==A) puts("A is equal to B");
    cout<<"We let the B[3] = A[3]-1"<<endl;
    B[3]=A[3]-1;
    printf("%d %d\n",A[3],B[3]);
    if(B!=A) puts("Now B[3] is different with A[3]");
    cout<<"Test the double Array,input 3 numbers please"<<endl;
    Array<double> C(3);
    cin>>C;
    cout<<"Here are the three numbers"<<endl;
    cout<<C;
    cout<<endl;
    cout<<"Now test the string array, please input five strings"<<endl;
    Array<string> D(5);
    cin>>D;
    cout<<D;
    cout<<endl;
    return 0;
}
