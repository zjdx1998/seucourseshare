#ifndef ARRAY_H
#define ARRAY_H
#include<bits/stdc++.h>
using namespace std;

template<typename T>
class Array{
    friend ostream& operator << (ostream& output,const Array<T>& a){
    for(int i=0;i<a.size;i++)
        output<<setprecision(5)<<setw(8)<<a.ptr[i];
    }

    friend istream& operator >> (istream& input,const Array<T>& a){
        for(int i=0;i<a.size;i++)
            input>>a.ptr[i];
    }

public:
    Array( int = 0 );
    Array( const Array<T> & );
    ~Array();
    int getSize() const;

    const Array<T>& operator = ( const Array<T> & );
    bool operator == ( const Array<T>& right ) const;

    bool operator != ( const Array<T>& right ) const{
        return !( *this==right );
    }
    int& operator [] ( const int );

    int operator [] (const int ) const;
private:
    int size;
    T *ptr;
};
template<typename T>
Array<T>::Array( int arraySize ){
    if(arraySize>0) size=arraySize;
    else
        throw invalid_argument("Array size must be greater than 0");
    ptr = new T[size];
}
template<typename T>
Array<T>::Array(const Array<T> &arrayToCopy):size(arrayToCopy.size){
    ptr = new T[size];
    for(int i=0;i<size;i++) ptr[i]=arrayToCopy.ptr[i];
}
template<typename T>
Array<T>::~Array(){
    delete []ptr;
}
template<typename T>
int Array<T>::getSize() const{return size;}

template<typename T>
const Array<T>& Array<T>::operator = (const Array<T>& right){
    if(&right!=this){
        if(size!=right.size){
            delete *ptr;
            size=right.size;
            ptr = new T[size];
        }
        for(int i=0;i<size;i++) ptr[i]=right.ptr[i];
    }
    return *this;
}

template<typename T>
bool Array<T>::operator == (const Array<T>& right) const{
    if(size!=right.size) return false;
    for(int i=0;i<size;i++)
        if(ptr[i]!=right.ptr[i]) return false;
    return true;
}

template<typename T>
int& Array<T>::operator [] (int subscript){
    if(subscript<0||subscript>=size) throw out_of_range("Subscript out of range");
    return ptr[subscript];
}

template<typename T>
int Array<T>::operator [] (int subscript) const{
    if(subscript<0||subscript>=size) throw out_of_range("Subscript out of range");
    return ptr[subscript];
}

#endif
