#include<bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i=0;i<n;i++)
void printAttr(const string& s,int style){//neat format
    cout<<"Neat Format Print Overloading"<<endl;
    rep(i,s.size()) cout<<setw(3)<<s[i];
    cout<<endl;
}

void printAttr(const string& s,double style){//tabular format
    cout<<"Tabular Format Print Overloading"<<endl;
    rep(i,s.size())
        if(i%3==0 && i) cout<<setw(3)<<s[i]<<endl;
        else            cout<<setw(3)<<s[i];
}

void printAttr(const string& s,char style){//column format
    cout<<"Column Format Print Overloading"<<endl;
    rep(i,s.size()) cout<<setw(3)<<s[i]<<endl;
}

int main(){
    string str;
    cin>>str;
    printAttr(str,1);
    printAttr(str,2.0);
    printAttr(str,'3');
    return 0; 
}