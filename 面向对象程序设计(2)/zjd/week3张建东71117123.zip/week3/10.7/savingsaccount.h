class SavingsAccount{
public:
    SavingsAccount(double,double);
    void calculateMonthlyInterest();
    void Print() const;
    static void modifyInterestRate(double newInterest);
private:
    static double annualInterestRate;
    double savingsBalance; //currently has on the deposit
};