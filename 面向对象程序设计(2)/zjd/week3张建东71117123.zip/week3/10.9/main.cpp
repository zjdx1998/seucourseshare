#include "mytime.h"
#include "mytime.cpp"

int main(){
    Time A(23,12,04);
    A.printUniversal();
    A.setHour(1);
    A.printStandard();
    A.setMinute(20);
    A.printStandard();
    return 0;
}