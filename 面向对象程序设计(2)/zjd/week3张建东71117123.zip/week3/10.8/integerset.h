const int N = 110;

class IntegerSet{
public:
    IntegerSet();
    IntegerSet(int a[],int size);
    void errorPrint() const;
    static IntegerSet unionOfSets(IntegerSet,IntegerSet);
    static IntegerSet intersectionOfSets(IntegerSet,IntegerSet);
    void insertElement(int k);
    void deleteElement(int k);
    void printSet() const;
    bool isEqualTo(IntegerSet &A) const; 
private:
    bool s[N];
};