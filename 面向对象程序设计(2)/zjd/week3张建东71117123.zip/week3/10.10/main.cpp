#include "card.cpp"

int main(){
    DeckOfCards d;
    d.shuffle();
    rep(i,52)
        cout<<d.dealCard().toString()<<endl;
    if(!d.moreCards()) puts("No cards left!");
    return 0;
}