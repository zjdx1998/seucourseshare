#include "card.h"
#include<sstream>

string Card::faces[14];
string Card::suits[5];

Card::Card(int f,int s):face(f),suit(s){
    faces[1] = "A";
    for(int i=2;i<=10;i++) {
        ostringstream os;
        os<<i;
        faces[i] = os.str();
        //faces[i] = to_string(i); 
    }
    faces[11]="J";faces[12]="Q";faces[13]="K";
    suits[1]="spades";suits[2]="hearts";
    suits[3]="diamonds";suits[4]="clubs";
}

string Card::toString(){
    return faces[face] + " of " + suits[suit];
}

DeckOfCards::DeckOfCards():currentCard(0){
    srand(time(NULL));
    rep(i,13)
        rep(j,4)
            deck.push_back(Card(i,j));
}

void DeckOfCards::shuffle(){
    currentCard=0;
    int cnt = 3600;//times of shuffling
    rep(i,cnt){
        int x = rand()%52 , y = rand()%52;
        Card t = deck[x];
        deck[x] = deck[y];
        deck[y] = t;
    }
}

bool DeckOfCards::moreCards(){
    if(currentCard>=52) return false;
    return true;
}

Card DeckOfCards::dealCard(){
    return deck[currentCard++];
}
