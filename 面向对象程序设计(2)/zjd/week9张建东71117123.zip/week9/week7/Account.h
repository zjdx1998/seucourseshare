#ifndef ACCOUNT_H
#define ACCOUNT_H

class Account{
public:
    Account(double); //initialize and check
    void credit(double);
    bool debit(double);
    void setBalance(double);
    double getBalance();
private:
    double balance;
};
#endif
