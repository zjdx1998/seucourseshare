#include "CheckingAccount.h"

CheckingAccount::CheckingAccount(double nbalance,double nfee)
:Account(nbalance){
    if(nfee<0) nfee=0;
    fee = nfee;
}

void CheckingAccount::credit(double pbalance){
    Account::credit(pbalance);
    minusfee();
}

void CheckingAccount::debit(double dbalance){
    if(Account::debit(dbalance)) minusfee();
}

void CheckingAccount::minusfee(){
    setBalance(getBalance()-fee);
}