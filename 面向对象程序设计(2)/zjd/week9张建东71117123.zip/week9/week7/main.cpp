#include "Account.h"
#include "CheckingAccount.h"
#include "SavingsAccount.h"
#include<iostream>
#include<iomanip>
#include<cstdio>
using namespace std;
int main(){
    Account A(100);
    SavingsAccount B(200,0.003);
    CheckingAccount C(300,0.3);
    puts("--------------Here's Account test---------------");
    A.credit(500);
    cout<<"After credit 500,now the balance is "<<setprecision(5)<<A.getBalance()<<endl;
    A.debit(700);
    A.debit(100);
    cout<<"After debit 100,now the balance is "<<setprecision(5)<<A.getBalance()<<endl;
    puts("----------Here's SavingsAccount test-------------");
    puts("Firstly , B has 200 balance with 0.03 interestrate");
    B.credit(B.calculateInterest());
    cout<<"Now B has the balance with interest:"<<B.getBalance()<<endl;
    B.debit(300);
    puts("----------Here's CheckingAccount test------------");
    puts("Firstly , C has 300 balance,and the fee is 0.3");
    C.credit(500);
    cout<<"Now C has the balance with 500 credited and fee charged:"<<C.getBalance()<<endl;
    C.debit(1000);
    C.debit(100);
    cout<<"Now C has the balance with 100 debited and fee charged:"<<C.getBalance()<<endl;
    return 0;
}
