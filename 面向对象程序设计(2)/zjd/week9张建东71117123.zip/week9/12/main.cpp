﻿#include<bits/stdc++.h>
#include "Employee.h"
#include "SalariedEmployee.h"
#include "CommissionEmployee.h"
#include "BasePlusCommissionEmployee.h"
using namespace std;
//作业添加内容**********************************
int determineMonth(){
    time_t currentTime;
    time( &currentTime );
    return localtime( &currentTime )->tm_mon+1;
}
//********************************************
int main() {
    cout << fixed << setprecision(2);
    vector <Employee *> employees(3);
    employees[0]=new SalariedEmployee("John", "Smith", "111-11-1111", 1, 1, 1998, 800 );
    employees[1] = new CommissionEmployee("Sue", "Jones", "333-33-3333", 3, 3, 1999, 10000, .06 );
    employees[2] = new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444", 4, 4, 2000, 5000, .04, 300 );

    int month = determineMonth();

    cout << "Employees processed polymorphically via dynamic binding:\n\n";

    for (size_t i=0;i<employees.size();i++){
        employees[i]->print();
        cout << endl;
        BasePlusCommissionEmployee *derivedPtr =
            dynamic_cast < BasePlusCommissionEmployee * >(employees[i]);
        if ( derivedPtr != 0 ) {
            double oldBaseSalary = derivedPtr->getBaseSalary();
            cout << "old base salary: $" << oldBaseSalary << endl;
            derivedPtr->setBaseSalary( 1.10 * oldBaseSalary );
            cout << "new base salary with 10% increase is: $"
                 << derivedPtr->getBaseSalary() << endl;
        }
//***********************************************************
//以下为作业要求添加的部分。
        Date birthday = employees[i]->getBirthDate();
        if (birthday.getMonth() == month)
            cout << "HAPPY BIRTHDAY!\nearned $"
                 << (employees[i]->earnings() + 100.0) << endl;
        else
            cout << "earned $" << employees[i]->earnings() << endl;

        cout << endl;
    }
//****************************************************************
    for (size_t j = 0; j < employees.size(); j++) {
        cout << "deleting object of "
             << typeid( *employees[j] ).name() << endl;

        delete employees[j];
    }
}
