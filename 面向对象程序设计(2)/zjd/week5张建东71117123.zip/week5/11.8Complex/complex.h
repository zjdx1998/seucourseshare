#ifndef COMPLEX_H
#define COMPLEX_H
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

class Complex{
    inline friend ostream& operator <<(ostream& output,const Complex& A);
    inline friend istream& operator >>(istream& input,Complex& A);
public:
    Complex(double r=0,double i=0):real(r),imagin(i){};
    inline Complex operator - (const Complex& A) const;
    inline Complex operator + (const Complex& A) const;
    inline bool operator ==(const Complex& A) const;
    inline bool operator !=(const Complex& A) const;
    inline Complex operator * (const Complex& A) const;
private:
    double real,imagin;
};

#endif
