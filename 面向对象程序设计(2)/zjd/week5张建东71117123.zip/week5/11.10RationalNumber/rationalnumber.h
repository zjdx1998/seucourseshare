#ifndef RN_H
#define RN_H
#include<iostream>
using namespace std;
class RationalNumber{//分母不<=0,化简 大小关系
public:
    RationalNumber():nume(0),deno(1){};
    RationalNumber(int n,int d);
    inline RationalNumber operator + (RationalNumber& A);
    inline RationalNumber operator - (RationalNumber& A);
    inline RationalNumber operator * (RationalNumber& A);
    inline RationalNumber operator / (RationalNumber& A);

    inline bool operator >= (RationalNumber& A);
    inline bool operator >  (RationalNumber& A);
    inline bool operator == (RationalNumber& A);
    inline bool operator <= (RationalNumber& A);
    inline bool operator <  (RationalNumber& A);
    inline bool operator !=  (RationalNumber& A);

    inline friend ostream& operator << (ostream&,RationalNumber&);

private:
    int nume,deno;
    int GetGcd(int a,int b);
    void f_std(int &a,int &b);
    void f_std();
};

#endif
