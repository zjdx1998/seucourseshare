#include "RationalNumber.cpp"
#include <cstdlib>
int main(){
    RationalNumber A(-5,-6),B(3,4);
    RationalNumber C = A - B;
    cout<<C<<endl;
    C = A * B;
    cout<<"A*B is" << endl<< C <<endl;
    if(C>A) cout<<"C is larger than A"<<endl;
    else     cout<< "C is smaller than A"<<endl;
    RationalNumber D(6,8);
    if(D==B) cout<<"D is equal to B"<<endl;
    else     cout<<"D is not equal to B"<<endl;
    RationalNumber E(5,0);
    C = B - A;
    cout<< "B-A is "<< endl << C << endl;
    return 0;
}
