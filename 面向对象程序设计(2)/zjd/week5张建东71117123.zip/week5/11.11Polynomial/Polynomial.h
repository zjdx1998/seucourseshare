#ifndef POLY_H
#define POLY_H
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<iostream>
using namespace std;
const int N = 110;
class Polynomial{
    friend ostream& operator << (ostream&,Polynomial&);
public:
    inline void Set(int,int);
    inline int Get(int) const;
    inline void SetMP(int) ;
    inline int GetMP() const;
    Polynomial();
    ~Polynomial();
    Polynomial operator + (const Polynomial&) const;
    Polynomial operator - (const Polynomial&) const;
    Polynomial operator * (const Polynomial&) const;
    Polynomial operator = (const Polynomial&);
    Polynomial operator +=(const Polynomial&);
    Polynomial operator -=(const Polynomial&);
    Polynomial operator *=(const Polynomial&);
private:
    int dig[N],MaxPower;
};

#endif
