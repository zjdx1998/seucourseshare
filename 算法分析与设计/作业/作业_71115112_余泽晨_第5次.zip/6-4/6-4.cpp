#include<iostream>
#include<algorithm>
#include<fstream>
#include<string>
#include<stdlib.h>

#include"Knap1.h"
#include"Goods.h"

using namespace std;

int Knapsack(int *p, int *w, int c, int n, int *bestx) {
	int W = 0;
	int P = 0;
	Goods* UnitValue = new Goods[n];
	for (int i = 0; i < n; i++) {
		UnitValue[i].unitValue = 1.0*p[i + 1] / w[i + 1];
		UnitValue[i].ID = i + 1;
		P += p[i + 1];
		W += w[i + 1];
	}
	if (W <= c)
		return P;

	sort(UnitValue, UnitValue + n);
	reverse(UnitValue, UnitValue + n);

	Knap knapsack;
	knapsack.p = new int[n + 1];
	knapsack.w = new int[n + 1];
	for (int i = 1; i <= n; i++) {
		knapsack.p[i] = p[UnitValue[i - 1].ID];
		knapsack.w[i] = w[UnitValue[i - 1].ID];
	}
	knapsack.n = n;
	knapsack.c = c;
	knapsack.cp = knapsack.cw = 0;
	int bestp = knapsack.MaxKnapSack();
	for (int j = 1; j <= n; j++)
		bestx[UnitValue[j - 1].ID] = knapsack.bestx[j];

	delete[]knapsack.w;
	delete[]knapsack.p;
	delete[]knapsack.bestx;
	delete[]UnitValue;

	return bestp;
}

int main() {
	ifstream infile("D:/input.txt");
	ofstream outfile("D:/output.txt", ios::out);

	int c;
	infile >> c;
	//cout << c << endl;

	int i = 1, count = 1;
	string str;
	infile >> str;
	//cout << str << endl;

	char* s;
	int len = str.length();
	s = (char *)malloc((len + 1)*sizeof(char));
	str.copy(s, len, 0);
	//cout << s << endl;

	for (int j = 0; j < len; j++)
		if (s[j] == ',')
			count++;

	int *p = new int[count + 1];
	char *substr = strtok(s, ",");
	while (substr != NULL) {
		p[i++] = atoi(substr);
		//cout << atoi(substr) << endl;
		substr = strtok(NULL, ",");
	}

	infile >> str;
	//cout << str << endl;
	len = str.length();

	s = (char *)malloc((len + 1)*sizeof(char));
	str.copy(s, len, 0);
	//cout << s << endl;

	int *w = new int[count + 1];
	i = 1;
	substr = strtok(s, ",");
	while (substr != NULL) {
		w[i++] = atoi(substr);
		//cout << atoi(substr) << endl;
		substr = strtok(NULL, ",");
	}

	int *bestx = new int[count + 1];
	int b = Knapsack(p, w, c, count, bestx);
	outfile << b << endl;
	cout << b << endl;
	for (int j = 1; j <= count; j++)
		outfile << bestx[j] << ' ';
	for (int j = 1; j <= count; j++)
		cout << bestx[j] << ' ';

	system("pause");
	return 0;
}