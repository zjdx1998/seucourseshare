#pragma once
class HeapNode
{
	friend class Knap;
public:
	operator int() const { return uprofit; }//���ýڵ��Ȩֵ

private:
	int uprofit, profit;
	int weight;
	int level;
	int *x;
};
