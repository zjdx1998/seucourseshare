#include<iostream>
#include<fstream>

#include"Traveling.h"

using namespace std;

int main() {
	ifstream infile("./input.txt");
	ofstream outfile("./output.txt", ios::out);
	int n,m;

	infile >> n >> m;
	int* v = new int[n + 1];
	Traveling t;
	t.n = n;
	t.bestp = new int[n];
	t.a = new int*[n + 1];
	t.cc = t.bestc = 0;
	for (int i = 1; i <= n; i++)
		t.a[i] = new int[n + 1];
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			infile >> t.a[i][j];

	
	int bestp = t.BBTSP(v);
	if (bestp == Traveling::NoEdge) {
		outfile << "No Loop!";
	}
	else {
		outfile << t.BBTSP(v) << endl;
		for (int i = 1; i <= n; i++)
			outfile << v[i] << ' ';
	}
	
	system("pause");
	return 0;
}