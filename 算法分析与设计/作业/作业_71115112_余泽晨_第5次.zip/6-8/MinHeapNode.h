#pragma once
class MinHeapNode
{
	friend class Traveling;
public:
	operator int() const { return lcost; }//���ýڵ�Ȩֵ
private:
	int lcost,
		cc,
		rcost;
	int s,
		*x;
};
