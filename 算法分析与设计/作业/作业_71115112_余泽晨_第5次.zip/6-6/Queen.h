#pragma once
#include<queue>
#include"QNode.h"
using namespace std;
class Queen
{
	friend int main();
public:
	Queen(int n) {
		this->n = n;
	}
	bool NQueen();
	bool Constrain(QNode &E) {
		for (int j = 1; j < E.i; j++)
			if ((abs(E.i - j) == abs(E.x[j]- E.x[E.i])) || (E.x[E.i] == E.x[j]))
				return false;
		return true;
	}
	 void NewNode(QNode& N,QNode& E,int i) {
		N.x = new int[n + 1];
		N.i = E.i + 1;
		for (int j = 1; j <= n; j++)
			N.x[j] = E.x[j];
		N.x[N.i] = E.x[i];
		N.x[i] = E.x[N.i];
	}

private:
	int n,
		*bestx;
	bool found;
	//int sum;
};

bool Queen::NQueen() {
	queue<QNode> Q;
	QNode E;
	E.x = new int[n + 1];
	for (int j = 1; j <= n; j++)
		E.x[j] = j;
	E.i = 0;
	bestx = new int[n + 1];
	found = false;

	while (true) {	
		if (E.i == n) {
			for (int j = 1; j <= n; j++)
				bestx[j] = E.x[j];
			found = true;
		}
		else {
			for (int j = E.i + 1; j <= n; j++) {
				QNode N;
				NewNode(N, E, j);
//��������н�Ľڵ���������
				if (Constrain(N))
					Q.push(N);
			}
		}
		if (found || Q.empty())
			break;
		else {
			E = Q.front();			
			Q.pop();
		}
	}
	return found;
}