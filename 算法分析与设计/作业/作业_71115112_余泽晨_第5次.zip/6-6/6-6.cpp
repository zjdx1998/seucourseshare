#include<iostream>
#include<fstream>
#include"Queen.h"

using namespace std;

int main() {
	ifstream infile("./input.txt");
	ofstream outfile("./output.txt", ios::out);
	int n;
	infile >> n;
	Queen queen(n);
	if (queen.NQueen())
		for (int j = 1; j <= n; j++)
			outfile << queen.bestx[j] << ' ';
	else
		outfile << "No Solution!";
	system("pause");
	return 0;
}