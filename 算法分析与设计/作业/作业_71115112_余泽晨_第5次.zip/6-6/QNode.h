#pragma once
class QNode {
	friend class Queen;
private:
	int i,
		*x;
};