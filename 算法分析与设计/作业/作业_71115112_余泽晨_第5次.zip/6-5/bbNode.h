#pragma once
class bbNode
{
	friend class Knap;
	friend int Knapsack(int*, int*, int, int, int*);
	
private:
	bbNode* parent;
	bool LChild;
};