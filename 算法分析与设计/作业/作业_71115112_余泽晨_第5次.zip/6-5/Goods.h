#pragma once
class Goods
{
	friend int Knapsack(int*, int*, int, int, int*);
public:
	bool operator< (const Goods& a) const {
		return (unitValue < a.unitValue);
	}

private:
	int ID;
	float unitValue;
};

