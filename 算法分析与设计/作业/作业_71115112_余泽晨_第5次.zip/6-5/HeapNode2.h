#pragma once
#include"bbNode.h"

class HeapNode
{
	friend class Knap;
public:
	operator int() const{ return uprofit; }//���ýڵ��Ȩֵ

private:
	int uprofit;
	int profit;
	int weight;
	int level;
	bbNode *ptr;
};
