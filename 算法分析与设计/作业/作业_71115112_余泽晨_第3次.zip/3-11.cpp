#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int sum = 0;
int c = 0;
int* Find(string* s, int n) {
	bool InAlpha[26];
	int alpha[26] = { 0 };
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < 26; j++)
			InAlpha[j] = 0;
		int len = s[i].length();
 
		if (s[i][len - 1] == '+') {
			for (int j = 0; j < len - 2; j++)
				InAlpha[s[i][j] - 'A'] = 1;
			for (int j = 0; j < 26; j++)
				if (InAlpha[j] == 1)
					alpha[j]++;
		}

	}
	int max = 0;
	for (int i = 0; i < 26; i++)
		if (max < alpha[i]) {
			max = alpha[i];
		}
	sum = max;
	for (int i = 0; i < 26; i++)
		if (max == alpha[i])
			c++;
	int *a = new int[c];
	for (int i = 0,j=0; i < 26; i++)
		if (max == alpha[i])
			a[j++]=i;
	return a;
}
int main() {
	ifstream infile("./input.txt");
	ofstream outfile("./output.txt", ios::out);
	string temp;
	int n = 0;
	string s[250];
	while (getline(infile,temp)) {
		s[n++] = temp;
	}
	int *a = Find(s, n);
	outfile << sum << '\n';
	for (int i = 0; i < c; i++)
		outfile << '*' << (char)('A' + a[i]) << '*' << '\n';
	return 0;
}